import { useEffect, useState } from 'react'
import type { ActivityReward, Screen, User, SubjectKey } from './types'
import { Sidebar, BottomNav, C } from './ui'
import {
  createUserProfile,
  getAuthenticatedUser,
  loginAccount,
  logoutAccount,
  registerAccount,
  saveAuthenticatedUser,
} from './auth'
import { applyActivityResult } from './progress'

// Auth
import { LoginScreen, RegisterScreen, ForgotScreen } from './screens/Auth'
import { OnboardingScreen } from './screens/Onboarding'

// Main screens
import { HomeScreen } from './screens/Home'
import { JourneyScreen, SubjectMapScreen } from './screens/Journey'
import { QuestionScreen, PhaseResultScreen } from './screens/Question'
import { EssayHubScreen, EssayWriteScreen } from './screens/Essay'
import { SimulationsScreen, SimRunScreen, SimResultScreen } from './screens/Simulations'
import { PerformanceScreen } from './screens/Performance'
import { RankingScreen } from './screens/Ranking'
import { ProfileScreen } from './screens/Profile'
import { SettingsScreen } from './screens/Settings'

// Admin
import { AdminDashboard, AdminQuestionForm } from './screens/Admin'

// Auth-only screens (no chrome)
const AUTH_SCREENS: Screen[] = ['login', 'register', 'forgot', 'onboarding']
// Admin screens (separate layout)
const ADMIN_SCREENS: Screen[] = ['admin', 'admin-question']
const initialSessionUser = getAuthenticatedUser()

function App() {
  const [screen, setScreen] = useState<Screen>(initialSessionUser ? 'home' : 'login')
  const [user, setUser] = useState<User>(
    initialSessionUser ?? createUserProfile('Estudante', ''),
  )
  const [selectedSubject, setSelectedSubject] = useState<SubjectKey>('history')
  const [lastActivityReward, setLastActivityReward] = useState<ActivityReward | null>(null)

  const nav = (s: Screen) => setScreen(s)

  useEffect(() => {
    try {
      saveAuthenticatedUser(user)
    } catch {
      // The current state remains usable when browser storage is unavailable.
    }
  }, [user])

  async function handleLogin(email: string, password: string) {
    const authenticatedUser = await loginAccount(email, password)
    setUser(authenticatedUser)
    nav('home')
  }

  async function handleRegister(name: string, email: string, password: string) {
    const registeredUser = await registerAccount(name, email, password)
    setUser(registeredUser)
    nav('onboarding')
  }

  function handleLogout() {
    logoutAccount()
    setUser(createUserProfile('Estudante', ''))
    nav('login')
  }

  // ─── Auth / Onboarding ────────────────────────────────────────────
  if (AUTH_SCREENS.includes(screen)) {
    return (
      <div className="min-h-screen" style={{ background: C.bgDeep }}>
        {screen === 'login' && <LoginScreen onNav={nav} onLogin={handleLogin} />}
        {screen === 'register' && <RegisterScreen onNav={nav} onRegister={handleRegister} />}
        {screen === 'forgot' && <ForgotScreen onNav={nav} />}
        {screen === 'onboarding' && (
          <OnboardingScreen
            user={user}
            onComplete={(profile) => {
              setUser(currentUser => ({ ...currentUser, ...profile }))
              nav('home')
            }}
          />
        )}
      </div>
    )
  }

  // ─── Admin layout ─────────────────────────────────────────────────
  if (ADMIN_SCREENS.includes(screen)) {
    return (
      <div className="min-h-screen" style={{ background: '#060914' }}>
        {screen === 'admin' && <AdminDashboard onNav={nav} />}
        {screen === 'admin-question' && <AdminQuestionForm onNav={nav} />}
      </div>
    )
  }

  // ─── Main app layout ──────────────────────────────────────────────
  return (
    <div className="flex min-h-screen" style={{ background: C.bgDeep }}>
      {/* Desktop sidebar */}
      <Sidebar active={screen} onNav={nav} user={user} />

      {/* Content area */}
      <main
        className="flex-1 flex flex-col min-h-screen overflow-y-auto"
        style={{ paddingBottom: 'max(72px, calc(60px + env(safe-area-inset-bottom)))' }}
      >
        {screen === 'home' && <HomeScreen user={user} onNav={nav} />}

        {screen === 'journey' && (
          <JourneyScreen
            onNav={nav}
            onSelectSubject={(s) => setSelectedSubject(s)}
          />
        )}
        {screen === 'subject-map' && (
          <SubjectMapScreen
            subject={selectedSubject}
            onNav={nav}
            onStartPhase={() => nav('question')}
          />
        )}
        {screen === 'question' && (
          <QuestionScreen
            onNav={nav}
            onComplete={(result) => {
              setUser(currentUser => {
                const outcome = applyActivityResult(currentUser, result)
                setLastActivityReward(outcome.reward)
                return outcome.user
              })
            }}
          />
        )}
        {screen === 'phase-result' && <PhaseResultScreen onNav={nav} reward={lastActivityReward} />}

        {screen === 'essay-hub' && <EssayHubScreen onNav={nav} />}
        {screen === 'essay-write' && <EssayWriteScreen onNav={nav} />}

        {screen === 'simulations' && <SimulationsScreen onNav={nav} />}
        {screen === 'sim-run' && <SimRunScreen onNav={nav} />}
        {screen === 'sim-result' && <SimResultScreen onNav={nav} />}

        {screen === 'performance' && <PerformanceScreen onNav={nav} />}
        {screen === 'ranking' && <RankingScreen onNav={nav} />}

        {screen === 'profile' && <ProfileScreen user={user} onUserChange={setUser} onNav={nav} />}
        {screen === 'settings' && <SettingsScreen user={user} onLogout={handleLogout} />}
      </main>

      {/* Mobile bottom nav */}
      <BottomNav active={screen} onNav={nav} />
    </div>
  )
}

export default App
