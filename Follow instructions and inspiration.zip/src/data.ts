import type { User, Question, SubjectTheme, SubjectKey } from './types'

export const mockUser: User = {
  name: 'Gabriel',
  email: 'gabriel@email.com',
  level: 4,
  xp: 1850,
  coins: 320,
  streak: 7,
  league: 'silver',
  language: 'english',
  course: 'Direito',
  university: 'USP',
  avatar: {
    hair: '👦',
    clothes: '👕',
    accessories: '🎒',
    frames: '🟣',
  },
  ownedAvatarItems: {
    hair: ['👦'],
    clothes: ['👕'],
    accessories: ['🎒'],
    frames: ['🟣'],
  },
}

export const subjectMeta: Record<SubjectKey, {
  label: string; icon: string; color: string; gradient: string; bgGlow: string; description: string
}> = {
  history: {
    label: 'História',
    icon: '🏛️',
    color: '#f87171',
    gradient: 'linear-gradient(135deg, #ef4444, #dc2626)',
    bgGlow: 'rgba(239,68,68,0.15)',
    description: 'Do Brasil Colônia ao contemporâneo',
  },
  geography: {
    label: 'Geografia',
    icon: '🌎',
    color: '#4ade80',
    gradient: 'linear-gradient(135deg, #22c55e, #16a34a)',
    bgGlow: 'rgba(34,197,94,0.15)',
    description: 'Geopolítica, meio ambiente e urbanização',
  },
  philosophy: {
    label: 'Filosofia',
    icon: '🧠',
    color: '#c4b5fd',
    gradient: 'linear-gradient(135deg, #a78bfa, #7c3aed)',
    bgGlow: 'rgba(167,139,250,0.15)',
    description: 'Do pensamento clássico à filosofia moderna',
  },
  sociology: {
    label: 'Sociologia',
    icon: '👥',
    color: '#fb923c',
    gradient: 'linear-gradient(135deg, #f97316, #ea580c)',
    bgGlow: 'rgba(249,115,22,0.15)',
    description: 'Sociedade, cultura e movimentos sociais',
  },
  language: {
    label: 'Língua Estrangeira',
    icon: '🌐',
    color: '#60a5fa',
    gradient: 'linear-gradient(135deg, #3b82f6, #2563eb)',
    bgGlow: 'rgba(59,130,246,0.15)',
    description: 'Interpretação de textos em inglês ou espanhol',
  },
}

export const historyThemes: SubjectTheme[] = [
  {
    id: 'brasil-colonia', name: 'Brasil Colônia', subject: 'history',
    phases: [
      { id: 'bc-1', name: 'Fase 1', number: 1, stars: 3, locked: false, completed: true, questionsCount: 10 },
      { id: 'bc-2', name: 'Fase 2', number: 2, stars: 2, locked: false, completed: true, questionsCount: 10 },
      { id: 'bc-3', name: 'Fase 3', number: 3, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'bc-boss', name: 'Desafio do Tema', number: 4, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'brasil-imperio', name: 'Brasil Império', subject: 'history',
    phases: [
      { id: 'bi-1', name: 'Fase 1', number: 1, stars: 2, locked: false, completed: true, questionsCount: 10 },
      { id: 'bi-2', name: 'Fase 2', number: 2, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'bi-3', name: 'Fase 3', number: 3, stars: 0, locked: true, completed: false, questionsCount: 10 },
      { id: 'bi-boss', name: 'Desafio do Tema', number: 4, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'era-vargas', name: 'Era Vargas', subject: 'history',
    phases: [
      { id: 'ev-1', name: 'Fase 1', number: 1, stars: 3, locked: false, completed: true, questionsCount: 10 },
      { id: 'ev-2', name: 'Fase 2', number: 2, stars: 2, locked: false, completed: false, questionsCount: 10 },
      { id: 'ev-3', name: 'Fase 3', number: 3, stars: 0, locked: true, completed: false, questionsCount: 10 },
      { id: 'ev-boss', name: 'Desafio do Tema', number: 4, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'ditadura', name: 'Ditadura Militar', subject: 'history',
    phases: [
      { id: 'dt-1', name: 'Fase 1', number: 1, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'dt-2', name: 'Fase 2', number: 2, stars: 0, locked: true, completed: false, questionsCount: 10 },
      { id: 'dt-boss', name: 'Desafio do Tema', number: 3, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'brasil-contemporaneo', name: 'Brasil Contemporâneo', subject: 'history',
    phases: [
      { id: 'bc2-1', name: 'Fase 1', number: 1, stars: 0, locked: true, completed: false, questionsCount: 10 },
      { id: 'bc2-boss', name: 'Desafio do Tema', number: 2, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
]

export const geographyThemes: SubjectTheme[] = [
  {
    id: 'geopolitica', name: 'Geopolítica', subject: 'geography',
    phases: [
      { id: 'gp-1', name: 'Fase 1', number: 1, stars: 3, locked: false, completed: true, questionsCount: 10 },
      { id: 'gp-2', name: 'Fase 2', number: 2, stars: 1, locked: false, completed: false, questionsCount: 10 },
      { id: 'gp-boss', name: 'Desafio do Tema', number: 3, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'meio-ambiente', name: 'Meio Ambiente', subject: 'geography',
    phases: [
      { id: 'ma-1', name: 'Fase 1', number: 1, stars: 2, locked: false, completed: true, questionsCount: 10 },
      { id: 'ma-2', name: 'Fase 2', number: 2, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'ma-boss', name: 'Desafio do Tema', number: 3, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'urbanizacao', name: 'Urbanização', subject: 'geography',
    phases: [
      { id: 'ur-1', name: 'Fase 1', number: 1, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'ur-boss', name: 'Desafio do Tema', number: 2, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
]

export const philosophyThemes: SubjectTheme[] = [
  {
    id: 'filosofia-classica', name: 'Filosofia Clássica', subject: 'philosophy',
    phases: [
      { id: 'fc-1', name: 'Fase 1', number: 1, stars: 3, locked: false, completed: true, questionsCount: 10 },
      { id: 'fc-2', name: 'Fase 2', number: 2, stars: 2, locked: false, completed: false, questionsCount: 10 },
      { id: 'fc-boss', name: 'Desafio do Tema', number: 3, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'contratualismo', name: 'Contratualismo', subject: 'philosophy',
    phases: [
      { id: 'ct-1', name: 'Fase 1', number: 1, stars: 1, locked: false, completed: false, questionsCount: 10 },
      { id: 'ct-boss', name: 'Desafio do Tema', number: 2, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'etica-politica', name: 'Ética e Política', subject: 'philosophy',
    phases: [
      { id: 'ep-1', name: 'Fase 1', number: 1, stars: 0, locked: true, completed: false, questionsCount: 10 },
      { id: 'ep-boss', name: 'Desafio do Tema', number: 2, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
]

export const sociologyThemes: SubjectTheme[] = [
  {
    id: 'sociologia-classica', name: 'Sociologia Clássica', subject: 'sociology',
    phases: [
      { id: 'sc-1', name: 'Fase 1', number: 1, stars: 2, locked: false, completed: true, questionsCount: 10 },
      { id: 'sc-2', name: 'Fase 2', number: 2, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'sc-boss', name: 'Desafio do Tema', number: 3, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'movimentos-sociais', name: 'Movimentos Sociais', subject: 'sociology',
    phases: [
      { id: 'ms-1', name: 'Fase 1', number: 1, stars: 0, locked: false, completed: false, questionsCount: 10 },
      { id: 'ms-boss', name: 'Desafio do Tema', number: 2, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
]

export const languageThemes: SubjectTheme[] = [
  {
    id: 'reading-comp', name: 'Reading Comprehension', subject: 'language',
    phases: [
      { id: 'rc-1', name: 'Fase 1', number: 1, stars: 3, locked: false, completed: true, questionsCount: 10 },
      { id: 'rc-2', name: 'Fase 2', number: 2, stars: 1, locked: false, completed: false, questionsCount: 10 },
      { id: 'rc-boss', name: 'Desafio do Tema', number: 3, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
  {
    id: 'grammar-vocab', name: 'Grammar & Vocabulary', subject: 'language',
    phases: [
      { id: 'gv-1', name: 'Fase 1', number: 1, stars: 2, locked: false, completed: false, questionsCount: 10 },
      { id: 'gv-boss', name: 'Desafio do Tema', number: 2, stars: 0, locked: true, completed: false, questionsCount: 15, isBoss: true },
    ],
  },
]

export const themesBySubject: Record<SubjectKey, SubjectTheme[]> = {
  history: historyThemes,
  geography: geographyThemes,
  philosophy: philosophyThemes,
  sociology: sociologyThemes,
  language: languageThemes,
}

export const sampleQuestions: Question[] = [
  {
    id: 'q1',
    subject: 'history',
    theme: 'Era Vargas',
    subtheme: 'Industrialização',
    difficulty: 'medium',
    supportText: 'O governo de Getúlio Vargas (1930–1945) foi marcado por profundas transformações na estrutura econômica brasileira. A política de industrialização por substituição de importações, aliada ao intervencionismo estatal, modificou o perfil produtivo do país e consolidou o trabalhismo como base de legitimidade política.',
    source: 'Adaptado de FAUSTO, Boris. História do Brasil. São Paulo: Edusp, 2012.',
    statement: 'A respeito do governo Vargas e seu impacto na economia brasileira, é correto afirmar que:',
    options: [
      { id: 'A', text: 'A política agrário-exportadora foi mantida como pilar central do desenvolvimento econômico, sem alterações significativas.' },
      { id: 'B', text: 'O Estado assumiu papel central no processo de industrialização, criando empresas estatais estratégicas como a CSN e a CVRD.' },
      { id: 'C', text: 'A industrialização ocorreu exclusivamente por iniciativa do capital estrangeiro, sem participação do governo.' },
      { id: 'D', text: 'A classe operária foi completamente excluída das políticas trabalhistas do período getulista.' },
      { id: 'E', text: 'O Brasil manteve estrita neutralidade econômica durante toda a Segunda Guerra Mundial, sem participar de acordos comerciais.' },
    ],
    correct: 'B',
    hint: 'Lembre-se do lema "50 anos em 5" e pense no papel do Estado durante a Era Vargas. Quais grandes empresas nacionais foram criadas nesse período? Pense em CSN, CVRD, Petrobras... O Estado era o grande protagonista.',
    explanation: 'A Era Vargas foi marcada pelo nacional-desenvolvimentismo, com o Estado assumindo papel protagonista na industrialização. A criação da CSN (1941), da CVRD (1942) e, posteriormente, da Petrobras (1953), demonstra o intervencionismo estatal característico do período. Vargas promoveu a industrialização por substituição de importações, enfraquecendo a dependência agrário-exportadora herdada da República Velha. A alternativa B é a única que reflete corretamente essa realidade histórica.',
  },
  {
    id: 'q2',
    subject: 'geography',
    theme: 'Geopolítica',
    subtheme: 'Globalização',
    difficulty: 'easy',
    statement: 'A globalização, fenômeno característico das décadas finais do século XX e início do XXI, pode ser melhor definida como:',
    options: [
      { id: 'A', text: 'A uniformização completa das culturas e tradições locais em escala mundial, eliminando as diferenças regionais.' },
      { id: 'B', text: 'A intensificação das relações econômicas, culturais e políticas entre países, com acelerados fluxos de capital, tecnologia e informação.' },
      { id: 'C', text: 'O processo de industrialização iniciado exclusivamente nos países em desenvolvimento após a Segunda Guerra Mundial.' },
      { id: 'D', text: 'A hegemonia militar dos Estados Unidos sobre as demais nações, consolidada após o fim da Guerra Fria.' },
      { id: 'E', text: 'A criação de blocos econômicos regionais como resposta protetora à integração mundial e às crises financeiras.' },
    ],
    correct: 'B',
    hint: 'A globalização é um processo multidimensional — não se limita à economia. Pense nos fluxos que se intensificaram: capital financeiro, informação via internet, migração, comércio de bens. O que acontece com as conexões entre os países?',
    explanation: 'A globalização é um processo multidimensional que intensifica as interdependências entre países. Envolve fluxos de capital financeiro, comércio de bens e serviços, migração, difusão tecnológica e intercâmbio cultural. É importante notar que a globalização não uniformiza culturas — ela coexiste com a valorização das identidades locais (fenômeno chamado de glocalização). A alternativa B sintetiza corretamente esse processo complexo e multifacetado.',
  },
  {
    id: 'q3',
    subject: 'philosophy',
    theme: 'Contratualismo',
    subtheme: 'Estado e Sociedade',
    difficulty: 'medium',
    supportText: '"O homem nasce livre, e por toda parte encontra-se a ferros. O que se crê senhor dos demais, não deixa de ser mais escravo do que eles." — Jean-Jacques Rousseau, Do Contrato Social, 1762.',
    statement: 'Analisando o pensamento contratualista de Rousseau na citação acima, é possível afirmar que:',
    options: [
      { id: 'A', text: 'Rousseau defende a monarquia absoluta como a forma mais legítima de organização política da sociedade.' },
      { id: 'B', text: 'Para Rousseau, a liberdade natural do homem é preservada integralmente na sociedade civil moderna.' },
      { id: 'C', text: 'A crítica de Rousseau aponta que a sociedade civil corrompeu a liberdade natural, criando desigualdades artificiais.' },
      { id: 'D', text: 'O filósofo defende que a escravidão é uma instituição natural e necessária para a ordem social.' },
      { id: 'E', text: 'Rousseau argumenta que a liberdade individual deve ser completamente submetida ao poder do soberano.' },
    ],
    correct: 'C',
    hint: 'Rousseau acreditava que o homem é naturalmente bom — a "bondade natural". O que, então, teria corrompido essa bondade? Pense na oposição entre estado de natureza e estado civil em Rousseau.',
    explanation: 'Rousseau distingue o estado de natureza (onde o homem é livre e bom) do estado civil (onde a propriedade privada e as instituições criaram desigualdades artificiais). A frase "nasce livre, mas encontra-se a ferros" expressa exatamente essa tensão: a sociedade, ao invés de garantir a liberdade, criou novas formas de dominação. A alternativa C capta corretamente essa crítica rousseauniana à civilização e à sociedade burguesa emergente.',
  },
]

export const leaderboard = [
  { pos: 1, name: 'Beatriz M.', level: 12, score: 4820, league: 'gold', isMe: false },
  { pos: 2, name: 'Pedro H.', level: 11, score: 4650, league: 'gold', isMe: false },
  { pos: 3, name: 'Larissa F.', level: 10, score: 4410, league: 'gold', isMe: false },
  { pos: 4, name: 'Carlos A.', level: 9, score: 3980, league: 'silver', isMe: false },
  { pos: 5, name: 'Mariana S.', level: 8, score: 3720, league: 'silver', isMe: false },
  { pos: 6, name: 'Você', level: 4, score: 1850, league: 'silver', isMe: true },
  { pos: 7, name: 'Thiago L.', level: 4, score: 1720, league: 'silver', isMe: false },
  { pos: 8, name: 'Ana P.', level: 3, score: 1540, league: 'bronze', isMe: false },
  { pos: 9, name: 'Rafael S.', level: 3, score: 1320, league: 'bronze', isMe: false },
  { pos: 10, name: 'Júlia W.', level: 2, score: 980, league: 'bronze', isMe: false },
]

export const performanceBySubject: Record<SubjectKey, { pct: number; trend: number }> = {
  history: { pct: 72, trend: 8 },
  geography: { pct: 58, trend: -3 },
  philosophy: { pct: 81, trend: 12 },
  sociology: { pct: 43, trend: 5 },
  language: { pct: 88, trend: 4 },
}

export const weakTopics = [
  { subject: 'history' as SubjectKey, topic: 'Era Vargas', pct: 42 },
  { subject: 'geography' as SubjectKey, topic: 'Geopolítica', pct: 51 },
  { subject: 'philosophy' as SubjectKey, topic: 'Contratualismo', pct: 48 },
  { subject: 'sociology' as SubjectKey, topic: 'Movimentos Sociais', pct: 38 },
]
