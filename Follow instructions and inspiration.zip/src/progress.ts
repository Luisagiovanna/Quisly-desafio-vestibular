import type { ActivityResult, ActivityReward, User, UserStats } from './types'

export const emptyStats: UserStats = {
  questionsAnswered: 0,
  correctAnswers: 0,
  activitiesCompleted: 0,
  bestCorrectStreak: 0,
  perfectActivities: 0,
  totalStars: 0,
}

export const achievementDefinitions = [
  {
    id: 'first-activity',
    icon: '🚀',
    title: 'Primeira missão',
    desc: 'Conclua sua primeira atividade',
    reward: 25,
    isUnlocked: (stats: UserStats) => stats.activitiesCompleted >= 1,
  },
  {
    id: 'first-answer',
    icon: '📝',
    title: 'Primeiro passo',
    desc: 'Responda sua primeira questão',
    reward: 20,
    isUnlocked: (stats: UserStats) => stats.questionsAnswered >= 1,
  },
  {
    id: 'five-correct',
    icon: '✅',
    title: 'Conhecimento em ação',
    desc: 'Acerte 5 questões',
    reward: 35,
    isUnlocked: (stats: UserStats) => stats.correctAnswers >= 5,
  },
  {
    id: 'ten-questions',
    icon: '📚',
    title: 'Ritmo de estudos',
    desc: 'Responda 10 questões',
    reward: 30,
    isUnlocked: (stats: UserStats) => stats.questionsAnswered >= 10,
  },
  {
    id: 'five-streak',
    icon: '🔥',
    title: 'Mente afiada',
    desc: 'Acerte 5 questões consecutivas',
    reward: 40,
    isUnlocked: (stats: UserStats) => stats.bestCorrectStreak >= 5,
  },
  {
    id: 'perfect-activity',
    icon: '⭐',
    title: 'Fase perfeita',
    desc: 'Acerte todas as questões de uma atividade',
    reward: 60,
    isUnlocked: (stats: UserStats) => stats.perfectActivities >= 1,
  },
] as const

function starsForResult(correct: number, total: number) {
  const percentage = total > 0 ? (correct / total) * 100 : 0
  if (percentage >= 90) return 3
  if (percentage >= 70) return 2
  if (percentage >= 50) return 1
  return 0
}

export function applyActivityResult(user: User, result: ActivityResult): {
  user: User
  reward: ActivityReward
} {
  const previousStats = user.stats ?? emptyStats
  const stars = starsForResult(result.correct, result.total)
  const stats: UserStats = {
    questionsAnswered: previousStats.questionsAnswered + result.total,
    correctAnswers: previousStats.correctAnswers + result.correct,
    activitiesCompleted: previousStats.activitiesCompleted + 1,
    bestCorrectStreak: Math.max(previousStats.bestCorrectStreak, result.bestCorrectStreak),
    perfectActivities: previousStats.perfectActivities + (result.correct === result.total ? 1 : 0),
    totalStars: previousStats.totalStars + stars,
  }

  const previouslyUnlocked = user.unlockedAchievements ?? []
  const unlockedAchievements = achievementDefinitions
    .filter(achievement => (
      !previouslyUnlocked.includes(achievement.id) && achievement.isUnlocked(stats)
    ))
    .map(achievement => achievement.id)
  const achievementCoins = achievementDefinitions
    .filter(achievement => unlockedAchievements.includes(achievement.id))
    .reduce((total, achievement) => total + achievement.reward, 0)
  const answerCoins = result.correct * 5
  const xp = result.correct * 10

  return {
    user: {
      ...user,
      xp: user.xp + xp,
      coins: user.coins + answerCoins + achievementCoins,
      level: Math.floor((user.xp + xp) / 500) + 1,
      stats,
      unlockedAchievements: [...previouslyUnlocked, ...unlockedAchievements],
    },
    reward: {
      ...result,
      stars,
      xp,
      answerCoins,
      achievementCoins,
      totalCoins: answerCoins + achievementCoins,
      unlockedAchievements,
    },
  }
}
