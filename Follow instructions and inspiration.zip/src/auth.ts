import type { User } from './types'
import { emptyStats } from './progress'

const ACCOUNTS_STORAGE_KEY = 'desafio-vestibular:accounts'
const SESSION_STORAGE_KEY = 'desafio-vestibular:session'

interface StoredAccount {
  email: string
  passwordHash: string
  salt: string
  user: User
}

function normalizeEmail(email: string) {
  return email.trim().toLowerCase()
}

function readAccounts(): StoredAccount[] {
  try {
    const value = localStorage.getItem(ACCOUNTS_STORAGE_KEY)
    if (!value) return []
    const accounts = JSON.parse(value)
    return Array.isArray(accounts) ? accounts : []
  } catch {
    return []
  }
}

function writeAccounts(accounts: StoredAccount[]) {
  try {
    localStorage.setItem(ACCOUNTS_STORAGE_KEY, JSON.stringify(accounts))
  } catch {
    throw new Error('Não foi possível salvar os dados neste navegador.')
  }
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = ''
  bytes.forEach(byte => {
    binary += String.fromCharCode(byte)
  })
  return btoa(binary)
}

function base64ToBytes(value: string) {
  const binary = atob(value)
  return Uint8Array.from(binary, character => character.charCodeAt(0))
}

async function hashPassword(password: string, salt: string) {
  const passwordKey = await crypto.subtle.importKey(
    'raw',
    new TextEncoder().encode(password),
    'PBKDF2',
    false,
    ['deriveBits'],
  )
  const hash = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      hash: 'SHA-256',
      salt: base64ToBytes(salt),
      iterations: 100_000,
    },
    passwordKey,
    256,
  )
  return bytesToBase64(new Uint8Array(hash))
}

export function createUserProfile(name: string, email: string): User {
  return {
    name: name.trim(),
    email: normalizeEmail(email),
    level: 1,
    xp: 0,
    coins: 0,
    streak: 0,
    league: 'bronze',
    language: 'english',
    avatar: {
      hair: '👦',
      clothes: '👕',
      accessories: '🎒',
      frames: '🟣',
    },
    ownedAvatarItems: {
      hair: ['👦'],
      clothes: ['👕'],
      accessories: ['🎒'],
      frames: ['🟣'],
    },
    stats: { ...emptyStats },
    unlockedAchievements: [],
  }
}

export async function registerAccount(name: string, email: string, password: string) {
  const normalizedEmail = normalizeEmail(email)
  const accounts = readAccounts()
  if (accounts.some(account => account.email === normalizedEmail)) {
    throw new Error('Já existe uma conta cadastrada com este e-mail.')
  }

  const salt = bytesToBase64(crypto.getRandomValues(new Uint8Array(16)))
  const user = createUserProfile(name, normalizedEmail)
  const account: StoredAccount = {
    email: normalizedEmail,
    salt,
    passwordHash: await hashPassword(password, salt),
    user,
  }

  writeAccounts([...accounts, account])
  localStorage.setItem(SESSION_STORAGE_KEY, normalizedEmail)
  return user
}

export async function loginAccount(email: string, password: string) {
  const normalizedEmail = normalizeEmail(email)
  const account = readAccounts().find(item => item.email === normalizedEmail)
  if (!account || await hashPassword(password, account.salt) !== account.passwordHash) {
    throw new Error('E-mail ou senha incorretos.')
  }

  localStorage.setItem(SESSION_STORAGE_KEY, normalizedEmail)
  return account.user
}

export function getAuthenticatedUser() {
  try {
    const email = localStorage.getItem(SESSION_STORAGE_KEY)
    if (!email) return null
    return readAccounts().find(account => account.email === email)?.user ?? null
  } catch {
    return null
  }
}

export function saveAuthenticatedUser(user: User) {
  const sessionEmail = localStorage.getItem(SESSION_STORAGE_KEY)
  if (!sessionEmail) return

  const accounts = readAccounts()
  const accountIndex = accounts.findIndex(account => account.email === sessionEmail)
  if (accountIndex === -1) return

  accounts[accountIndex] = {
    ...accounts[accountIndex],
    user: { ...user, email: sessionEmail },
  }
  writeAccounts(accounts)
}

export function logoutAccount() {
  localStorage.removeItem(SESSION_STORAGE_KEY)
}
