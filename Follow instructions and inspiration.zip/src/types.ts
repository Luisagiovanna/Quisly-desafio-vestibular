export type Screen =
  | 'login' | 'register' | 'forgot'
  | 'onboarding'
  | 'home'
  | 'journey' | 'subject-map' | 'question' | 'phase-result'
  | 'essay-hub' | 'essay-write'
  | 'simulations' | 'sim-run' | 'sim-result'
  | 'performance'
  | 'ranking'
  | 'profile' | 'avatar-shop'
  | 'settings'
  | 'admin' | 'admin-question'

export type SubjectKey = 'history' | 'geography' | 'philosophy' | 'sociology' | 'language'

export type League = 'bronze' | 'silver' | 'gold' | 'diamond' | 'master'

export type AvatarCategory = 'hair' | 'clothes' | 'accessories' | 'frames'

export interface AvatarConfig {
  hair: string
  clothes: string
  accessories: string
  frames: string
}

export interface UserStats {
  questionsAnswered: number
  correctAnswers: number
  activitiesCompleted: number
  bestCorrectStreak: number
  perfectActivities: number
  totalStars: number
}

export interface ActivityResult {
  correct: number
  total: number
  bestCorrectStreak: number
}

export interface ActivityReward {
  correct: number
  total: number
  stars: number
  xp: number
  answerCoins: number
  achievementCoins: number
  totalCoins: number
  unlockedAchievements: string[]
}

export interface User {
  name: string
  email: string
  level: number
  xp: number
  coins: number
  streak: number
  league: League
  language: 'english' | 'spanish'
  course?: string
  university?: string
  avatar?: AvatarConfig
  ownedAvatarItems?: Partial<Record<AvatarCategory, string[]>>
  stats?: UserStats
  unlockedAchievements?: string[]
}

export interface QuestionOption {
  id: string
  text: string
}

export interface Question {
  id: string
  subject: SubjectKey
  theme: string
  subtheme: string
  difficulty: 'easy' | 'medium' | 'hard'
  supportText?: string
  source?: string
  statement: string
  options: QuestionOption[]
  correct: string
  hint: string
  explanation: string
}

export interface Phase {
  id: string
  name: string
  number: number
  stars: number
  locked: boolean
  completed: boolean
  questionsCount: number
  isBoss?: boolean
}

export interface SubjectTheme {
  id: string
  name: string
  subject: SubjectKey
  phases: Phase[]
}

export interface NavCtx {
  subject?: SubjectKey
  themeId?: string
  phaseId?: string
}
