import { useState, type ReactNode, type CSSProperties } from 'react'
import type { AvatarConfig, Screen, User, SubjectKey } from './types'
import { subjectMeta } from './data'

// ─── Color tokens ────────────────────────────────────────────────
export const C = {
  bgDeep: '#090c1e',
  bgSurface: '#0f1229',
  bgCard: '#151931',
  bgElevated: '#1c2040',
  primary: '#6366f1',
  primaryLight: '#818cf8',
  gold: '#f59e0b',
  goldLight: '#fbbf24',
  success: '#22c55e',
  error: '#ef4444',
  blue: '#3b82f6',
  orange: '#f97316',
  pink: '#ec4899',
  border: 'rgba(255,255,255,0.07)',
  borderStrong: 'rgba(255,255,255,0.14)',
  text: '#eef0ff',
  textSec: 'rgba(238,240,255,0.6)',
  textMuted: 'rgba(238,240,255,0.35)',
}

// ─── Button ──────────────────────────────────────────────────────
type BtnVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success' | 'gold' | 'outline'
type BtnSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl'

const btnVariants: Record<BtnVariant, CSSProperties> = {
  primary: { background: 'linear-gradient(135deg, #6366f1, #4f46e5)', border: '1px solid rgba(99,102,241,0.4)', color: '#fff', boxShadow: '0 4px 20px rgba(99,102,241,0.35)' },
  secondary: { background: 'rgba(255,255,255,0.07)', border: '1px solid rgba(255,255,255,0.12)', color: 'rgba(238,240,255,0.85)' },
  ghost: { background: 'transparent', border: '1px solid rgba(255,255,255,0.09)', color: C.textSec },
  danger: { background: 'linear-gradient(135deg, #ef4444, #dc2626)', border: '1px solid rgba(239,68,68,0.3)', color: '#fff', boxShadow: '0 4px 16px rgba(239,68,68,0.3)' },
  success: { background: 'linear-gradient(135deg, #22c55e, #16a34a)', border: '1px solid rgba(34,197,94,0.3)', color: '#fff', boxShadow: '0 4px 16px rgba(34,197,94,0.3)' },
  gold: { background: 'linear-gradient(135deg, #f59e0b, #d97706)', border: '1px solid rgba(245,158,11,0.3)', color: '#fff', boxShadow: '0 4px 16px rgba(245,158,11,0.3)' },
  outline: { background: 'transparent', border: '1px solid rgba(99,102,241,0.5)', color: C.primaryLight },
}
const btnSizes: Record<BtnSize, string> = {
  xs: 'px-2.5 py-1 text-xs rounded-lg',
  sm: 'px-3.5 py-2 text-xs rounded-xl',
  md: 'px-5 py-2.5 text-sm rounded-xl',
  lg: 'px-6 py-3 text-base rounded-xl',
  xl: 'px-8 py-4 text-lg rounded-2xl',
}

export function Btn({
  children, onClick, variant = 'primary', size = 'md', full = false,
  disabled = false, type = 'button', style: extraStyle,
}: {
  children: ReactNode; onClick?: () => void; variant?: BtnVariant; size?: BtnSize
  full?: boolean; disabled?: boolean; type?: 'button' | 'submit'; style?: CSSProperties
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`font-semibold transition-all hover:brightness-110 hover:scale-[1.02] active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed disabled:scale-100 ${btnSizes[size]} ${full ? 'w-full' : ''}`}
      style={{ fontFamily: "'Nunito', sans-serif", ...btnVariants[variant], ...extraStyle }}
    >
      {children}
    </button>
  )
}

// ─── Card ─────────────────────────────────────────────────────────
export function Card({
  children, className = '', onClick, elevated = false, glow, style, padding = 'p-5',
}: {
  children: ReactNode; className?: string; onClick?: () => void
  elevated?: boolean; glow?: string; style?: CSSProperties; padding?: string
}) {
  return (
    <div
      onClick={onClick}
      className={`rounded-2xl ${padding} transition-all ${onClick ? 'cursor-pointer hover:brightness-110' : ''} ${className}`}
      style={{
        background: elevated ? C.bgElevated : C.bgCard,
        border: `1px solid ${elevated ? C.borderStrong : C.border}`,
        boxShadow: glow ? `0 0 28px ${glow}` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  )
}

// ─── Badge ────────────────────────────────────────────────────────
export function Badge({ children, color = 'primary', size = 'sm' }: {
  children: ReactNode; color?: string; size?: 'xs' | 'sm' | 'md'
}) {
  const map: Record<string, { bg: string; text: string }> = {
    primary: { bg: 'rgba(99,102,241,0.18)', text: '#a5b4fc' },
    gold: { bg: 'rgba(245,158,11,0.18)', text: '#fbbf24' },
    success: { bg: 'rgba(34,197,94,0.18)', text: '#4ade80' },
    error: { bg: 'rgba(239,68,68,0.18)', text: '#f87171' },
    blue: { bg: 'rgba(59,130,246,0.18)', text: '#60a5fa' },
    orange: { bg: 'rgba(249,115,22,0.18)', text: '#fb923c' },
    pink: { bg: 'rgba(236,72,153,0.18)', text: '#f472b6' },
    muted: { bg: 'rgba(255,255,255,0.07)', text: C.textSec },
  }
  const c = map[color] || { bg: 'rgba(255,255,255,0.1)', text: '#eef0ff' }
  const sz = { xs: 'px-1.5 py-0.5 text-[10px] rounded-md', sm: 'px-2 py-1 text-xs rounded-lg', md: 'px-3 py-1.5 text-sm rounded-xl' }[size]
  return (
    <span className={`font-bold inline-flex items-center gap-1 ${sz}`} style={{ background: c.bg, color: c.text }}>
      {children}
    </span>
  )
}

// ─── Progress Bar ─────────────────────────────────────────────────
export function ProgressBar({ value, max = 100, color = C.primary, height = 8, animated = false }: {
  value: number; max?: number; color?: string; height?: number; animated?: boolean
}) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100))
  return (
    <div className="w-full rounded-full overflow-hidden" style={{ height, background: 'rgba(255,255,255,0.08)' }}>
      <div
        className={`h-full rounded-full ${animated ? 'transition-all duration-700' : ''}`}
        style={{ width: `${pct}%`, background: color }}
      />
    </div>
  )
}

export function XPBar({ xp, level }: { xp: number; level: number }) {
  const base = 500
  const cur = xp % base
  return (
    <div>
      <div className="flex justify-between text-xs mb-1" style={{ color: C.textMuted }}>
        <span>Nível {level}</span>
        <span>{cur}/{base} XP</span>
      </div>
      <ProgressBar value={cur} max={base} color={`linear-gradient(90deg, ${C.primary}, ${C.primaryLight})`} animated />
    </div>
  )
}

// ─── Stars ────────────────────────────────────────────────────────
export function Stars({ count, max = 3, size = 14 }: { count: number; max?: number; size?: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: max }).map((_, i) => (
        <span key={i} style={{ fontSize: size, color: i < count ? C.gold : 'rgba(255,255,255,0.15)' }}>★</span>
      ))}
    </div>
  )
}

// ─── Avatar ───────────────────────────────────────────────────────
const avatarFrameColors: Record<string, string> = {
  '🟣': '#8b5cf6',
  '🔵': '#3b82f6',
  '🟡': '#f59e0b',
  '🟢': '#22c55e',
  '🔴': '#ef4444',
  '🌈': '#ec4899',
  '⭐': '#fbbf24',
}

export function Avatar({
  name,
  size = 40,
  level,
  avatar,
}: {
  name: string
  size?: number
  level?: number
  avatar?: AvatarConfig
}) {
  const initials = name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
  const frameColor = avatarFrameColors[avatar?.frames ?? ''] ?? C.primary
  return (
    <div className="relative inline-flex flex-shrink-0">
      <div
        className="rounded-full flex items-center justify-center font-display font-bold text-white flex-shrink-0 relative overflow-hidden"
        style={{
          width: size, height: size,
          background: 'linear-gradient(135deg, #6366f1, #7c3aed)',
          fontSize: avatar ? size * 0.56 : size * 0.36,
          border: `${Math.max(2, size * 0.045)}px solid ${frameColor}`,
          boxShadow: avatar?.frames === '🌈'
            ? `0 0 ${size * 0.2}px rgba(236,72,153,0.55)`
            : `0 0 ${size * 0.14}px ${frameColor}55`,
        }}
      >
        {avatar?.hair ?? initials}
        {avatar && (
          <>
            <span
              className="absolute leading-none"
              style={{ left: size * 0.04, bottom: size * 0.03, fontSize: size * 0.27 }}
              aria-hidden="true"
            >
              {avatar.clothes}
            </span>
            <span
              className="absolute leading-none"
              style={{ right: size * 0.02, top: size * 0.03, fontSize: size * 0.25 }}
              aria-hidden="true"
            >
              {avatar.accessories}
            </span>
          </>
        )}
      </div>
      {level !== undefined && (
        <div
          className="absolute -bottom-1 -right-1 rounded-full flex items-center justify-center text-white font-bold"
          style={{ width: size * 0.38, height: size * 0.38, background: 'linear-gradient(135deg,#f59e0b,#d97706)', fontSize: size * 0.17, border: `1.5px solid ${C.bgDeep}` }}
        >
          {level}
        </div>
      )}
    </div>
  )
}

// ─── League Badge ─────────────────────────────────────────────────
const leagues: Record<string, { icon: string; label: string; color: string }> = {
  bronze: { icon: '🥉', label: 'Bronze', color: '#d97706' },
  silver: { icon: '🥈', label: 'Prata', color: '#94a3b8' },
  gold: { icon: '🥇', label: 'Ouro', color: '#f59e0b' },
  diamond: { icon: '💎', label: 'Diamante', color: '#67e8f9' },
  master: { icon: '👑', label: 'Mestre', color: '#a78bfa' },
}

export function LeagueBadge({ league, size = 'sm' }: { league: string; size?: 'xs' | 'sm' | 'md' }) {
  const l = leagues[league] || leagues.bronze
  const sz = { xs: 'px-1.5 py-0.5 text-[10px] rounded-md', sm: 'px-2.5 py-1 text-xs rounded-lg', md: 'px-3 py-1.5 text-sm rounded-xl' }[size]
  return (
    <span className={`inline-flex items-center gap-1 font-bold ${sz}`} style={{ background: `${l.color}1a`, color: l.color }}>
      {l.icon} {l.label}
    </span>
  )
}

// ─── Stat Chip ────────────────────────────────────────────────────
export function StatChip({ icon, value, label, color = C.primaryLight }: {
  icon: string; value: string | number; label?: string; color?: string
}) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-base leading-none">{icon}</span>
      <span className="font-bold text-sm leading-none" style={{ color }}>{value}</span>
      {label && <span className="text-xs leading-none" style={{ color: C.textMuted }}>{label}</span>}
    </div>
  )
}

// ─── Divider ──────────────────────────────────────────────────────
export function Divider({ label }: { label?: string }) {
  if (!label) return <div className="h-px w-full" style={{ background: C.border }} />
  return (
    <div className="flex items-center gap-3">
      <div className="flex-1 h-px" style={{ background: C.border }} />
      <span className="text-xs font-semibold" style={{ color: C.textMuted }}>{label}</span>
      <div className="flex-1 h-px" style={{ background: C.border }} />
    </div>
  )
}

// ─── Input ────────────────────────────────────────────────────────
export function Input({
  label, type = 'text', value, onChange, placeholder, icon, required, hint,
}: {
  label?: string; type?: string; value: string; onChange: (v: string) => void
  placeholder?: string; icon?: string; required?: boolean; hint?: string
}) {
  const [show, setShow] = useState(false)
  const isPw = type === 'password'
  return (
    <div className="flex flex-col gap-1.5">
      {label && (
        <label className="text-sm font-semibold" style={{ color: C.textSec }}>
          {label}{required && <span className="text-red-400 ml-0.5">*</span>}
        </label>
      )}
      <div
        className="flex items-center gap-2.5 rounded-xl px-4 py-3 transition-all focus-within:outline focus-within:outline-2 focus-within:outline-indigo-500/40"
        style={{ background: 'rgba(255,255,255,0.05)', border: `1px solid ${C.border}` }}
      >
        {icon && <span className="opacity-50 text-base flex-shrink-0">{icon}</span>}
        <input
          type={isPw && show ? 'text' : type}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          required={required}
          className="flex-1 bg-transparent outline-none text-sm placeholder-white/25"
          style={{ color: C.text }}
        />
        {isPw && (
          <button type="button" onClick={() => setShow(s => !s)} className="opacity-35 hover:opacity-60 transition-opacity text-sm flex-shrink-0">
            {show ? '🙈' : '👁️'}
          </button>
        )}
      </div>
      {hint && <p className="text-xs" style={{ color: C.textMuted }}>{hint}</p>}
    </div>
  )
}

// ─── Select ───────────────────────────────────────────────────────
export function Select({
  label, value, onChange, options, placeholder,
}: {
  label?: string; value: string; onChange: (v: string) => void
  options: { value: string; label: string }[]; placeholder?: string
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold" style={{ color: C.textSec }}>{label}</label>}
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        className="rounded-xl px-4 py-3 text-sm outline-none focus:outline-indigo-500/40"
        style={{ background: 'rgba(255,255,255,0.05)', border: `1px solid ${C.border}`, color: C.text }}
      >
        {placeholder && <option value="" style={{ background: C.bgElevated }}>{placeholder}</option>}
        {options.map(o => (
          <option key={o.value} value={o.value} style={{ background: C.bgElevated }}>{o.label}</option>
        ))}
      </select>
    </div>
  )
}

// ─── Textarea ─────────────────────────────────────────────────────
export function Textarea({ label, value, onChange, placeholder, rows = 8 }: {
  label?: string; value: string; onChange: (v: string) => void; placeholder?: string; rows?: number
}) {
  return (
    <div className="flex flex-col gap-1.5">
      {label && <label className="text-sm font-semibold" style={{ color: C.textSec }}>{label}</label>}
      <textarea
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="rounded-xl px-4 py-3 text-sm outline-none focus:outline-indigo-500/40 resize-none"
        style={{ background: 'rgba(255,255,255,0.05)', border: `1px solid ${C.border}`, color: C.text }}
      />
    </div>
  )
}

// ─── Modal ────────────────────────────────────────────────────────
export function Modal({ open, onClose, children, title, wide = false }: {
  open: boolean; onClose: () => void; children: ReactNode; title?: string; wide?: boolean
}) {
  if (!open) return null
  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={onClose}
    >
      <div
        className={`w-full ${wide ? 'max-w-2xl' : 'max-w-sm'} rounded-2xl p-6 flex flex-col gap-4`}
        style={{ background: C.bgElevated, border: `1px solid ${C.borderStrong}`, boxShadow: '0 32px 80px rgba(0,0,0,0.7)' }}
        onClick={e => e.stopPropagation()}
      >
        {title && <h3 className="font-display text-xl font-semibold" style={{ color: C.text }}>{title}</h3>}
        {children}
      </div>
    </div>
  )
}

// ─── Alert ────────────────────────────────────────────────────────
export function Alert({ type, children }: { type: 'error' | 'success' | 'info' | 'warning'; children: ReactNode }) {
  const styles = {
    error: { bg: 'rgba(239,68,68,0.12)', border: 'rgba(239,68,68,0.25)', color: '#fca5a5', icon: '⚠️' },
    success: { bg: 'rgba(34,197,94,0.12)', border: 'rgba(34,197,94,0.25)', color: '#86efac', icon: '✓' },
    info: { bg: 'rgba(99,102,241,0.12)', border: 'rgba(99,102,241,0.25)', color: '#a5b4fc', icon: 'ℹ️' },
    warning: { bg: 'rgba(245,158,11,0.12)', border: 'rgba(245,158,11,0.25)', color: '#fde68a', icon: '💡' },
  }[type]
  return (
    <div className="flex items-start gap-2.5 rounded-xl px-4 py-3 text-sm"
      style={{ background: styles.bg, border: `1px solid ${styles.border}`, color: styles.color }}>
      <span className="flex-shrink-0">{styles.icon}</span>
      <span>{children}</span>
    </div>
  )
}

// ─── Section Title ────────────────────────────────────────────────
export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h2 className="font-display font-semibold text-lg" style={{ color: C.text }}>{children}</h2>
      {action}
    </div>
  )
}

// ─── Empty State ──────────────────────────────────────────────────
export function EmptyState({ icon, title, description }: { icon: string; title: string; description?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-14 text-center gap-3">
      <div className="text-5xl">{icon}</div>
      <div className="font-semibold" style={{ color: C.textSec }}>{title}</div>
      {description && <div className="text-sm max-w-xs" style={{ color: C.textMuted }}>{description}</div>}
    </div>
  )
}

// ─── Subject Chip ─────────────────────────────────────────────────
export function SubjectChip({ subject }: { subject: SubjectKey }) {
  const m = subjectMeta[subject]
  return (
    <span
      className="inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold"
      style={{ background: `${m.color}1a`, color: m.color }}
    >
      {m.icon} {m.label}
    </span>
  )
}

// ─── Difficulty Chip ──────────────────────────────────────────────
export function DifficultyChip({ level }: { level: 'easy' | 'medium' | 'hard' }) {
  const map = { easy: { label: 'Fácil', color: 'success' }, medium: { label: 'Médio', color: 'gold' }, hard: { label: 'Difícil', color: 'error' } }
  const m = map[level]
  return <Badge color={m.color}>{m.label}</Badge>
}

// ─── Back Header ──────────────────────────────────────────────────
export function BackHeader({ title, onBack, right }: { title?: string; onBack: () => void; right?: ReactNode }) {
  return (
    <div
      className="flex items-center gap-3 px-4 py-3 flex-shrink-0"
      style={{ background: C.bgSurface, borderBottom: `1px solid ${C.border}` }}
    >
      <button onClick={onBack} className="w-9 h-9 rounded-xl flex items-center justify-center transition-all hover:bg-white/8" style={{ color: C.textSec }}>
        ←
      </button>
      {title && <div className="font-display font-semibold text-base flex-1" style={{ color: C.text }}>{title}</div>}
      {right && <div className="ml-auto">{right}</div>}
    </div>
  )
}

// ─── Bottom Navigation ────────────────────────────────────────────
export function BottomNav({ active, onNav }: { active: string; onNav: (s: Screen) => void }) {
  const items: { id: Screen; icon: string; label: string }[] = [
    { id: 'home', icon: '🏠', label: 'Início' },
    { id: 'journey', icon: '🗺️', label: 'Jornada' },
    { id: 'essay-hub', icon: '✍️', label: 'Redação' },
    { id: 'ranking', icon: '🏆', label: 'Ranking' },
    { id: 'profile', icon: '👤', label: 'Perfil' },
  ]
  return (
    <nav
      className="fixed bottom-0 left-0 right-0 md:hidden z-40 flex justify-around"
      style={{
        background: 'rgba(9,12,30,0.96)', backdropFilter: 'blur(16px)',
        borderTop: `1px solid ${C.border}`,
        paddingBottom: 'max(8px, env(safe-area-inset-bottom))',
        paddingTop: 8,
      }}
    >
      {items.map(item => (
        <button
          key={item.id}
          onClick={() => onNav(item.id)}
          className="flex flex-col items-center gap-0.5 px-4 py-1 rounded-xl transition-all"
          style={{ color: active === item.id ? C.primaryLight : C.textMuted }}
        >
          <span className="text-[20px] leading-none">{item.icon}</span>
          <span className="text-[10px] font-bold">{item.label}</span>
        </button>
      ))}
    </nav>
  )
}

// ─── Sidebar ──────────────────────────────────────────────────────
export function Sidebar({ active, onNav, user }: { active: string; onNav: (s: Screen) => void; user: User }) {
  const items: { id: Screen; icon: string; label: string }[] = [
    { id: 'home', icon: '🏠', label: 'Início' },
    { id: 'journey', icon: '🗺️', label: 'Jornada' },
    { id: 'essay-hub', icon: '✍️', label: 'Redação' },
    { id: 'simulations', icon: '📝', label: 'Simulados' },
    { id: 'performance', icon: '📊', label: 'Desempenho' },
    { id: 'ranking', icon: '🏆', label: 'Ranking' },
    { id: 'profile', icon: '👤', label: 'Perfil' },
    { id: 'settings', icon: '⚙️', label: 'Configurações' },
  ]
  return (
    <aside
      className="hidden md:flex flex-col w-60 flex-shrink-0 h-screen sticky top-0 overflow-y-auto"
      style={{ background: C.bgSurface, borderRight: `1px solid ${C.border}` }}
    >
      {/* Logo */}
      <div className="px-5 py-6 flex-shrink-0">
        <div className="font-display font-bold" style={{ fontSize: 22, color: C.gold, lineHeight: 1.1 }}>DESAFIO</div>
        <div className="font-display font-bold" style={{ fontSize: 22, color: C.primaryLight, lineHeight: 1.1 }}>VESTIBULAR</div>
        <div className="text-xs mt-1" style={{ color: C.textMuted }}>Prepare-se para o ENEM</div>
      </div>
      {/* User mini */}
      <div className="mx-3 mb-4 p-3 rounded-xl flex-shrink-0" style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-2.5 mb-2.5">
          <Avatar name={user.name} size={36} level={user.level} avatar={user.avatar} />
          <div>
            <div className="text-sm font-bold leading-tight" style={{ color: C.text }}>{user.name}</div>
            <LeagueBadge league={user.league} size="xs" />
          </div>
        </div>
        <XPBar xp={user.xp} level={user.level} />
        <div className="flex gap-3 mt-2.5">
          <StatChip icon="⭐" value={user.xp.toLocaleString()} color={C.primaryLight} />
          <StatChip icon="🪙" value={user.coins} color={C.gold} />
          <StatChip icon="🔥" value={`${user.streak}d`} color="#fb923c" />
        </div>
      </div>
      {/* Nav */}
      <nav className="flex-1 px-2 flex flex-col gap-0.5">
        {items.map(item => (
          <button
            key={item.id}
            onClick={() => onNav(item.id)}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-semibold text-left transition-all hover:bg-white/5"
            style={{
              background: active === item.id ? 'rgba(99,102,241,0.14)' : 'transparent',
              color: active === item.id ? C.primaryLight : C.textSec,
              borderLeft: `2px solid ${active === item.id ? C.primary : 'transparent'}`,
            }}
          >
            <span className="text-base leading-none">{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>
      <div className="px-2 pb-4 flex-shrink-0">
        <button
          onClick={() => onNav('admin')}
          className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold w-full transition-all hover:bg-white/5"
          style={{ color: C.textMuted }}
        >
          🔧 Painel Admin
        </button>
      </div>
    </aside>
  )
}

// ─── Page shell (with bottom nav spacing) ─────────────────────────
export function Page({ children, className = '' }: { children: ReactNode; className?: string }) {
  return (
    <div className={`flex-1 overflow-y-auto ${className}`} style={{ paddingBottom: 'calc(72px + env(safe-area-inset-bottom))' }}>
      {children}
    </div>
  )
}

// ─── Auth page wrapper ────────────────────────────────────────────
export function AuthPage({ children }: { children: ReactNode }) {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center relative px-5 py-10 overflow-hidden"
      style={{ background: `radial-gradient(ellipse at 60% 30%, #1a1050 0%, ${C.bgDeep} 65%)` }}
    >
      {/* Star field */}
      <div className="absolute inset-0 pointer-events-none">
        {Array.from({ length: 50 }).map((_, i) => (
          <div key={i} className="absolute rounded-full bg-white" style={{
            width: (i % 3) + 1, height: (i % 3) + 1,
            top: `${(i * 7.7) % 100}%`, left: `${(i * 13.1) % 100}%`,
            opacity: 0.06 + (i % 5) * 0.04,
          }} />
        ))}
      </div>
      <div className="relative z-10 w-full max-w-sm">{children}</div>
    </div>
  )
}

// ─── Logo ─────────────────────────────────────────────────────────
export function Logo({ size = 'lg' }: { size?: 'sm' | 'md' | 'lg' }) {
  const sz = { sm: 24, md: 32, lg: 42 }[size]
  return (
    <div className="text-center">
      <div className="font-display font-bold leading-none" style={{ fontSize: sz, background: 'linear-gradient(135deg, #f59e0b, #fde68a)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
        DESAFIO
      </div>
      <div className="font-display font-bold leading-none" style={{ fontSize: sz, background: 'linear-gradient(135deg, #818cf8, #6366f1)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
        VESTIBULAR
      </div>
    </div>
  )
}
