import { useState } from 'react'
import type { AvatarCategory, AvatarConfig, Screen, User } from '../types'
import { Card, Avatar, Badge, LeagueBadge, Stars, XPBar, Page, C, SectionTitle, Divider, Alert } from '../ui'
import { achievementDefinitions, emptyStats } from '../progress'

type ProfileTab = 'stats' | 'achievements' | 'avatar'

const avatarItems = {
  hair: ['👦', '👦🏻', '👦🏽', '👦🏿', '🧑‍🦱', '🧑‍🦳', '🧑‍🦰'],
  clothes: ['👕', '🧥', '🎽', '👔', '🧣', '🧤', '🧦'],
  accessories: ['🎒', '👓', '🎧', '⌚', '🎩', '👑', '🏅'],
  frames: ['🟣', '🔵', '🟡', '🟢', '🔴', '🌈', '⭐'],
}

const defaultAvatar: AvatarConfig = {
  hair: avatarItems.hair[0],
  clothes: avatarItems.clothes[0],
  accessories: avatarItems.accessories[0],
  frames: avatarItems.frames[0],
}

export function ProfileScreen({
  user,
  onNav,
  onUserChange,
}: {
  user: User
  onNav: (s: Screen) => void
  onUserChange: (user: User) => void
}) {
  const [tab, setTab] = useState<ProfileTab>('stats')
  const [avatarMessage, setAvatarMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const xpForLevel = 500
  const currentXP = user.xp % xpForLevel
  const equippedAvatar = { ...defaultAvatar, ...user.avatar }
  const stats = user.stats ?? emptyStats
  const unlockedAchievements = user.unlockedAchievements ?? []
  const achievements = achievementDefinitions.map(achievement => ({
    ...achievement,
    done: unlockedAchievements.includes(achievement.id),
  }))
  const accuracy = stats.questionsAnswered > 0
    ? Math.round((stats.correctAnswers / stats.questionsAnswered) * 100)
    : 0

  function selectAvatarItem(category: AvatarCategory, item: string, isFreeItem: boolean) {
    const ownedItems = user.ownedAvatarItems?.[category] ?? []
    const isOwned = isFreeItem || ownedItems.includes(item)

    if (!isOwned && user.coins < 50) {
      setAvatarMessage({ type: 'error', text: 'Você precisa de 50 moedas para desbloquear este item.' })
      return
    }

    const nextOwnedItems = isOwned ? ownedItems : [...ownedItems, item]
    onUserChange({
      ...user,
      coins: isOwned ? user.coins : user.coins - 50,
      avatar: { ...equippedAvatar, [category]: item },
      ownedAvatarItems: {
        ...user.ownedAvatarItems,
        [category]: nextOwnedItems,
      },
    })
    setAvatarMessage({
      type: 'success',
      text: isOwned ? 'Avatar atualizado e salvo.' : 'Item desbloqueado, equipado e salvo.',
    })
  }

  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-5 max-w-3xl mx-auto">
        {/* Profile header */}
        <Card elevated padding="p-5">
          <div className="flex items-start gap-4">
            <div className="relative flex-shrink-0">
              <Avatar name={user.name} size={72} avatar={equippedAvatar} />
              <button
                onClick={() => setTab('avatar')}
                className="absolute -bottom-1 -right-1 w-7 h-7 rounded-full flex items-center justify-center text-sm"
                style={{ background: C.primary, border: `2px solid ${C.bgDeep}` }}
              >
                ✏️
              </button>
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-display text-2xl font-bold" style={{ color: C.text }}>{user.name}</div>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <LeagueBadge league={user.league} size="sm" />
                <Badge color="primary">Nível {user.level}</Badge>
                {user.course && <Badge color="muted">{user.course}</Badge>}
              </div>
              {user.university && (
                <div className="text-xs mt-1" style={{ color: C.textMuted }}>🏛️ {user.university}</div>
              )}
              <div className="mt-3">
                <XPBar xp={user.xp} level={user.level} />
              </div>
            </div>
          </div>

          {/* Mini stats */}
          <Divider />
          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              { icon: '⭐', val: user.xp.toLocaleString(), label: 'XP', color: C.primaryLight },
              { icon: '🪙', val: user.coins, label: 'moedas', color: C.gold },
              { icon: '🔥', val: `${user.streak}`, label: 'dias', color: '#fb923c' },
              { icon: '⭐', val: stats.totalStars, label: 'estrelas', color: C.gold },
            ].map(s => (
              <div key={s.label}>
                <div className="text-xl">{s.icon}</div>
                <div className="font-display font-bold text-lg" style={{ color: s.color }}>{s.val}</div>
                <div className="text-[10px]" style={{ color: C.textMuted }}>{s.label}</div>
              </div>
            ))}
          </div>
        </Card>

        {/* Tabs */}
        <div className="flex border-b gap-4" style={{ borderColor: C.border }}>
          {([
            { id: 'stats' as ProfileTab, label: '📊 Estatísticas' },
            { id: 'achievements' as ProfileTab, label: '🏅 Conquistas' },
            { id: 'avatar' as ProfileTab, label: '🎨 Avatar' },
          ]).map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="pb-2.5 text-sm font-semibold transition-all"
              style={{
                color: tab === t.id ? C.primaryLight : C.textMuted,
                borderBottom: `2px solid ${tab === t.id ? C.primary : 'transparent'}`,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Stats tab */}
        {tab === 'stats' && (
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: '📝', label: 'Questões respondidas', val: stats.questionsAnswered, color: C.primaryLight },
                { icon: '✅', label: 'Taxa de acerto', val: `${accuracy}%`, color: C.success },
                { icon: '🏛️', label: 'Fases concluídas', val: stats.activitiesCompleted, color: C.gold },
                { icon: '🔥', label: 'Melhor sequência', val: stats.bestCorrectStreak, color: '#fb923c' },
                { icon: '⭐', label: 'Fases perfeitas', val: stats.perfectActivities, color: '#f472b6' },
                { icon: '🏆', label: 'Conquistas', val: `${achievements.filter(a => a.done).length}/${achievements.length}`, color: C.gold },
              ].map(s => (
                <Card key={s.label} padding="p-4">
                  <div className="text-xl mb-1">{s.icon}</div>
                  <div className="font-display text-2xl font-bold" style={{ color: s.color }}>{s.val}</div>
                  <div className="text-xs" style={{ color: C.textMuted }}>{s.label}</div>
                </Card>
              ))}
            </div>

            {/* Stars per subject */}
            <SectionTitle>Estrelas por Matéria</SectionTitle>
            <div className="flex flex-col gap-2.5">
              {[
                { icon: '🏛️', label: 'História', stars: 11, max: 24 },
                { icon: '🌎', label: 'Geografia', stars: 7, max: 18 },
                { icon: '🧠', label: 'Filosofia', stars: 9, max: 15 },
                { icon: '👥', label: 'Sociologia', stars: 5, max: 12 },
                { icon: '🌐', label: 'Inglês', stars: 5, max: 9 },
              ].map(s => (
                <Card key={s.label} padding="p-3">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{s.icon}</span>
                    <span className="flex-1 text-sm font-semibold" style={{ color: C.text }}>{s.label}</span>
                    <Stars count={Math.round((s.stars / s.max) * 3)} />
                    <span className="text-xs font-semibold" style={{ color: C.gold }}>{s.stars}/{s.max}</span>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Achievements tab */}
        {tab === 'achievements' && (
          <div className="flex flex-col gap-3">
            <div className="text-sm" style={{ color: C.textMuted }}>
              {achievements.filter(a => a.done).length}/{achievements.length} conquistas desbloqueadas
            </div>
            <Alert type="info">
              Conclua atividades para desbloquear conquistas. Cada conquista paga moedas uma única vez.
            </Alert>
            {achievements.map(a => (
              <Card key={a.id} padding="p-4" style={{ opacity: a.done ? 1 : 0.5 }}>
                <div className="flex items-center gap-4">
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
                    style={{
                      background: a.done ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'rgba(255,255,255,0.05)',
                      boxShadow: a.done ? '0 4px 16px rgba(245,158,11,0.3)' : 'none',
                    }}
                  >
                    {a.icon}
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-sm" style={{ color: a.done ? C.text : C.textSec }}>{a.title}</div>
                    <div className="text-xs" style={{ color: C.textMuted }}>{a.desc}</div>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge color="gold">+{a.reward} 🪙</Badge>
                    {a.done && <Badge color="success">✓ Recebida</Badge>}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Avatar tab */}
        {tab === 'avatar' && (
          <div className="flex flex-col gap-5">
            <Card elevated padding="p-5">
              <div className="text-center mb-4">
                <Avatar name={user.name} size={96} avatar={equippedAvatar} />
                <div className="font-display text-lg font-bold mt-2" style={{ color: C.text }}>{user.name}</div>
                <div className="flex items-center justify-center gap-1 text-sm" style={{ color: C.gold }}>
                  <span>🪙</span><span>{user.coins} moedas disponíveis</span>
                </div>
              </div>
              <div className="text-center text-xs" style={{ color: C.textMuted }}>
                Compre itens cosméticos com moedas conquistadas estudando.<br />
                Tudo gratuito — sem compra com dinheiro real. O avatar fica salvo neste navegador.
              </div>
            </Card>

            {avatarMessage && <Alert type={avatarMessage.type}>{avatarMessage.text}</Alert>}

            {(Object.entries(avatarItems) as [keyof typeof avatarItems, string[]][]).map(([category, items]) => (
              <div key={category}>
                <SectionTitle>
                  {category === 'hair' ? '💇 Cabelo' : category === 'clothes' ? '👕 Roupas' : category === 'accessories' ? '👓 Acessórios' : '🖼️ Molduras'}
                </SectionTitle>
                <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                  {items.map((item, i) => {
                    const isEquipped = equippedAvatar[category] === item
                    const isOwned = i === 0 || (user.ownedAvatarItems?.[category] ?? []).includes(item)
                    return (
                      <button
                        key={item}
                        type="button"
                        onClick={() => selectAvatarItem(category, item, i === 0)}
                        aria-pressed={isEquipped}
                        aria-label={`${isEquipped ? 'Equipado' : isOwned ? 'Equipar' : 'Desbloquear'} ${item}`}
                        className="rounded-xl p-2 flex flex-col items-center gap-1 transition-all hover:scale-105 focus-visible:outline-2 focus-visible:outline-indigo-400"
                        style={{
                          background: isEquipped ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)',
                          border: `1px solid ${isEquipped ? 'rgba(99,102,241,0.55)' : C.border}`,
                        }}
                      >
                        <span className="text-2xl">{item}</span>
                        <span
                          className="text-[9px] font-bold"
                          style={{ color: isEquipped ? C.success : isOwned ? C.primaryLight : C.gold }}
                        >
                          {isEquipped ? 'Equipado' : isOwned ? 'Equipar' : '50🪙'}
                        </span>
                      </button>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Page>
  )
}
