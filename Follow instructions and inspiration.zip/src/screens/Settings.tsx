import { useState } from 'react'
import type { Screen, User } from '../types'
import { Card, Btn, BackHeader, Page, C, Divider } from '../ui'

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className="relative w-11 h-6 rounded-full transition-all flex-shrink-0"
      style={{ background: checked ? C.primary : 'rgba(255,255,255,0.15)' }}
    >
      <span
        className="absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform"
        style={{ transform: checked ? 'translateX(20px)' : 'translateX(0)' }}
      />
    </button>
  )
}

function SettingRow({ icon, label, desc, action, onClick }: {
  icon: string; label: string; desc?: string; action?: React.ReactNode; onClick?: () => void
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 py-3 w-full text-left ${onClick ? 'hover:bg-white/3 rounded-xl px-2 -mx-2 transition-all' : ''}`}
    >
      <span className="text-xl flex-shrink-0">{icon}</span>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-semibold" style={{ color: C.text }}>{label}</div>
        {desc && <div className="text-xs" style={{ color: C.textMuted }}>{desc}</div>}
      </div>
      {action || (onClick && <span className="text-sm" style={{ color: C.textMuted }}>›</span>)}
    </button>
  )
}

export function SettingsScreen({
  user,
  onLogout,
}: {
  user: User
  onLogout: () => void
}) {
  const [sound, setSound] = useState(true)
  const [music, setMusic] = useState(false)
  const [reduceAnim, setReduceAnim] = useState(false)
  const [notifications, setNotifications] = useState(true)
  const [dailyReminder, setDailyReminder] = useState(true)
  const [language, setLanguage] = useState<'english' | 'spanish'>(user.language)

  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-5 max-w-2xl mx-auto">
        <div>
          <h1 className="font-display text-2xl font-bold" style={{ color: C.text }}>⚙️ Configurações</h1>
        </div>

        {/* Account */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Conta</div>
          <div className="flex flex-col gap-1">
            <SettingRow icon="👤" label={user.name} desc="Editar nome e apelido" onClick={() => {}} />
            <Divider />
            <SettingRow icon="✉️" label="E-mail" desc={user.email} />
            <Divider />
            <SettingRow icon="🔒" label="Alterar senha" onClick={() => {}} />
          </div>
        </Card>

        {/* Foreign language */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Língua Estrangeira</div>
          <div className="text-sm mb-3" style={{ color: C.textSec }}>Escolha a língua que você selecionou para o ENEM:</div>
          <div className="flex gap-2">
            {[
              { key: 'english' as const, label: '🇺🇸 Inglês' },
              { key: 'spanish' as const, label: '🇪🇸 Espanhol' },
            ].map(l => (
              <button
                key={l.key}
                onClick={() => setLanguage(l.key)}
                className="flex-1 py-3 rounded-xl font-semibold text-sm transition-all"
                style={{
                  background: language === l.key ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)',
                  border: `1px solid ${language === l.key ? 'rgba(99,102,241,0.5)' : C.border}`,
                  color: language === l.key ? C.primaryLight : C.textSec,
                }}
              >
                {l.label}
              </button>
            ))}
          </div>
        </Card>

        {/* Audio */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Áudio</div>
          <div className="flex flex-col gap-1">
            <SettingRow icon="🔊" label="Sons do jogo" desc="Efeitos sonoros das interações" action={<Toggle checked={sound} onChange={setSound} />} />
            <Divider />
            <SettingRow icon="🎵" label="Música de fundo" desc="Trilha sonora durante os estudos" action={<Toggle checked={music} onChange={setMusic} />} />
          </div>
        </Card>

        {/* Accessibility */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Acessibilidade</div>
          <SettingRow icon="✨" label="Reduzir animações" desc="Para dispositivos mais lentos ou preferência pessoal" action={<Toggle checked={reduceAnim} onChange={setReduceAnim} />} />
        </Card>

        {/* Notifications */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Notificações</div>
          <div className="flex flex-col gap-1">
            <SettingRow icon="🔔" label="Notificações" desc="Avisos sobre metas e conquistas" action={<Toggle checked={notifications} onChange={setNotifications} />} />
            <Divider />
            <SettingRow icon="⏰" label="Lembrete diário" desc="Lembre-me de estudar todos os dias" action={<Toggle checked={dailyReminder} onChange={setDailyReminder} />} />
          </div>
        </Card>

        {/* Privacy */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Privacidade e Dados</div>
          <div className="flex flex-col gap-1">
            <SettingRow icon="🔐" label="Privacidade" desc="Como seus dados são utilizados" onClick={() => {}} />
            <Divider />
            <SettingRow icon="📄" label="Termos de uso" onClick={() => {}} />
            <Divider />
            <SettingRow icon="🗑️" label="Excluir conta" desc="Esta ação é irreversível" onClick={() => {}} />
          </div>
        </Card>

        {/* About */}
        <Card padding="p-4">
          <div className="text-xs font-bold uppercase tracking-wider mb-3" style={{ color: C.textMuted }}>Sobre</div>
          <div className="flex flex-col gap-1">
            <SettingRow icon="🎓" label="Desafio Vestibular" desc="v1.0.0 · 100% gratuito" />
            <Divider />
            <SettingRow icon="❤️" label="Feito para estudantes brasileiros" />
          </div>
        </Card>

        {/* Sign out */}
        <Btn variant="danger" size="lg" full onClick={onLogout}>
          🚪 Sair da conta
        </Btn>

        <div className="text-center text-xs pb-6" style={{ color: C.textMuted }}>
          Desafio Vestibular · 100% gratuito · Sem Premium · Sem paywall
        </div>
      </div>
    </Page>
  )
}
