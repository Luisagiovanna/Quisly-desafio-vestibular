import { useState } from 'react'
import type { Screen } from '../types'
import { Card, Btn, Badge, ProgressBar, BackHeader, Page, C, SectionTitle, Divider } from '../ui'

const essaySteps = [
  { id: 1, title: 'Estrutura da Redação', icon: '🏗️', desc: 'Entenda o formato dissertativo-argumentativo do ENEM', done: true },
  { id: 2, title: 'Introdução', icon: '🚀', desc: 'Como apresentar o tema e sua tese', done: true },
  { id: 3, title: 'Desenvolvimento', icon: '📝', desc: 'Construindo os parágrafos de argumentação', done: false },
  { id: 4, title: 'Argumentação', icon: '⚖️', desc: 'Técnicas para argumentos sólidos e coerentes', done: false },
  { id: 5, title: 'Repertório Sociocultural', icon: '🎭', desc: 'Como usar citações, dados e referências culturais', done: false },
  { id: 6, title: 'Coesão', icon: '🔗', desc: 'Conectivos e articulação entre ideias', done: false },
  { id: 7, title: 'Conclusão', icon: '🎯', desc: 'Fechamento eficaz da sua argumentação', done: false },
  { id: 8, title: 'Proposta de Intervenção', icon: '💡', desc: 'A proposta detalhada, agente e finalidade', done: false },
  { id: 9, title: 'Redação Completa', icon: '✅', desc: 'Pratique com temas reais do ENEM', done: false },
]

const competencies = [
  { id: 1, label: 'C1 – Norma culta', desc: 'Domínio da norma padrão da língua escrita', color: '#6366f1' },
  { id: 2, label: 'C2 – Compreender a proposta', desc: 'Entender e aplicar o tema proposto', color: '#3b82f6' },
  { id: 3, label: 'C3 – Selecionar argumentos', desc: 'Elaborar e selecionar informações e argumentos', color: '#22c55e' },
  { id: 4, label: 'C4 – Coesão textual', desc: 'Demonstrar conhecimento dos mecanismos linguísticos', color: '#f97316' },
  { id: 5, label: 'C5 – Proposta de intervenção', desc: 'Elaborar proposta de intervenção respeitando direitos humanos', color: '#ec4899' },
]

export function EssayHubScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const done = essaySteps.filter(s => s.done).length
  const pct = Math.round((done / essaySteps.length) * 100)

  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-5 max-w-3xl mx-auto">
        {/* Header */}
        <div className="flex flex-col gap-1">
          <h1 className="font-display text-2xl font-bold" style={{ color: C.text }}>✍️ Redação ENEM</h1>
          <p className="text-sm" style={{ color: C.textSec }}>Domine a redação dissertativo-argumentativa.</p>
        </div>

        {/* Progress */}
        <Card elevated>
          <div className="flex items-center justify-between mb-3">
            <div className="font-display text-lg font-semibold" style={{ color: C.text }}>Sua Jornada</div>
            <Badge color="primary">{done}/{essaySteps.length} etapas</Badge>
          </div>
          <ProgressBar value={done} max={essaySteps.length} color="linear-gradient(90deg,#ec4899,#db2777)" animated />
          <p className="text-xs mt-2" style={{ color: C.textMuted }}>{pct}% da jornada de redação concluída</p>
        </Card>

        {/* CTA */}
        <Card padding="p-0" style={{ background: 'linear-gradient(135deg, rgba(236,72,153,0.15), rgba(99,102,241,0.1))', border: '1px solid rgba(236,72,153,0.25)' }}>
          <div className="p-5 flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-1">
              <div className="font-display text-xl font-semibold mb-1" style={{ color: C.text }}>Desafio de Redação</div>
              <p className="text-sm" style={{ color: C.textSec }}>
                <strong style={{ color: '#f472b6' }}>Tema:</strong> Desafios para a implementação de políticas públicas de saúde mental no Brasil contemporâneo.
              </p>
              <div className="flex items-center gap-3 mt-2 text-xs" style={{ color: C.textMuted }}>
                <span>📄 3 textos motivadores</span>
                <span>⏱️ Sem limite de tempo</span>
              </div>
            </div>
            <Btn variant="primary" size="md" onClick={() => onNav('essay-write')}
              style={{ background: 'linear-gradient(135deg,#ec4899,#db2777)', border: '1px solid rgba(236,72,153,0.4)', color: '#fff', boxShadow: '0 4px 16px rgba(236,72,153,0.3)' }}>
              ✍️ ESCREVER
            </Btn>
          </div>
        </Card>

        {/* Journey steps */}
        <div>
          <SectionTitle>Jornada da Redação</SectionTitle>
          <div className="flex flex-col gap-2.5">
            {essaySteps.map((step, idx) => (
              <div key={step.id} className="flex gap-3">
                {/* Timeline */}
                <div className="flex flex-col items-center flex-shrink-0" style={{ width: 36 }}>
                  <div
                    className="w-9 h-9 rounded-xl flex items-center justify-center text-base flex-shrink-0"
                    style={{ background: step.done ? 'rgba(34,197,94,0.15)' : 'rgba(255,255,255,0.05)', border: `1px solid ${step.done ? 'rgba(34,197,94,0.3)' : C.border}` }}
                  >
                    {step.done ? '✓' : step.icon}
                  </div>
                  {idx < essaySteps.length - 1 && (
                    <div className="w-0.5 flex-1 mt-1" style={{ background: step.done ? 'rgba(34,197,94,0.2)' : C.border, minHeight: 12 }} />
                  )}
                </div>
                {/* Content */}
                <div
                  className={`flex-1 rounded-xl p-3.5 mb-2 ${!step.done && idx === done ? 'cursor-pointer hover:brightness-105' : ''}`}
                  style={{
                    background: step.done ? 'rgba(34,197,94,0.06)' : idx === done ? C.bgCard : 'rgba(255,255,255,0.02)',
                    border: `1px solid ${step.done ? 'rgba(34,197,94,0.2)' : idx === done ? C.borderStrong : C.border}`,
                  }}
                >
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="font-semibold text-sm" style={{ color: step.done ? '#4ade80' : idx === done ? C.text : C.textMuted }}>{step.title}</span>
                    {idx === done && <Badge color="primary" size="xs">Próxima</Badge>}
                  </div>
                  <p className="text-xs" style={{ color: C.textMuted }}>{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Competencies */}
        <div>
          <SectionTitle>5 Competências do ENEM</SectionTitle>
          <div className="flex flex-col gap-2">
            {competencies.map(c => (
              <Card key={c.id} padding="p-3.5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0"
                    style={{ background: `${c.color}20`, color: c.color }}>{c.id}</div>
                  <div>
                    <div className="font-semibold text-sm" style={{ color: C.text }}>{c.label}</div>
                    <div className="text-xs" style={{ color: C.textMuted }}>{c.desc}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </Page>
  )
}

export function EssayWriteScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const [text, setText] = useState('')
  const [saved, setSaved] = useState(false)
  const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length
  const charCount = text.length
  const maxWords = 30

  const motivatingTexts = [
    {
      label: 'Texto 1 – OMS (2022)',
      content: 'Segundo a Organização Mundial da Saúde, uma em cada quatro pessoas no mundo será afetada por transtorno mental ao longo da vida. No Brasil, o Sistema Único de Saúde (SUS) enfrenta desafios estruturais para oferecer atendimento psicológico e psiquiátrico universal.',
    },
    {
      label: 'Texto 2 – IPEA (2023)',
      content: 'Dados do Instituto de Pesquisa Econômica Aplicada indicam que apenas 3,4% do orçamento do Ministério da Saúde é destinado à saúde mental, percentual muito abaixo dos 5% recomendados pela OMS para países em desenvolvimento.',
    },
    {
      label: 'Texto 3 – Charge Ilustrativa',
      content: '[Charge representando um paciente aguardando meses por atendimento em serviço de saúde mental público, enquanto sistema privado é inacessível financeiramente para a maioria da população]',
    },
  ]

  return (
    <div className="flex flex-col min-h-screen" style={{ background: C.bgDeep }}>
      <BackHeader onBack={() => onNav('essay-hub')} title="Redação ENEM" right={
        <div className="text-xs font-semibold" style={{ color: wordCount > maxWords * 30 ? C.success : C.textMuted }}>
          {wordCount} palavras · {charCount} caracteres
        </div>
      } />

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-3xl mx-auto px-4 py-5 flex flex-col gap-5">
          {/* Theme */}
          <Card elevated padding="p-5">
            <div className="text-xs font-bold uppercase tracking-wider mb-2" style={{ color: '#f472b6' }}>Tema da Redação</div>
            <h2 className="font-display text-xl font-semibold leading-tight" style={{ color: C.text }}>
              Desafios para a implementação de políticas públicas de saúde mental no Brasil contemporâneo
            </h2>
            <Divider />
            <div className="text-xs font-semibold mb-2" style={{ color: C.textMuted }}>INSTRUÇÃO:</div>
            <p className="text-sm leading-relaxed" style={{ color: C.textSec }}>
              Com base na leitura dos textos motivadores e nos conhecimentos construídos ao longo de sua formação, redija um texto dissertativo-argumentativo em modalidade escrita formal da língua portuguesa sobre o tema acima, apresentando proposta de intervenção que respeite os direitos humanos. Selecione, organize e relacione argumentos e fatos para defender sua tese.
            </p>
          </Card>

          {/* Motivating texts */}
          <div>
            <SectionTitle>Textos Motivadores</SectionTitle>
            <div className="flex flex-col gap-3">
              {motivatingTexts.map((t, i) => (
                <Card key={i} padding="p-4">
                  <div className="text-xs font-bold mb-2" style={{ color: C.primaryLight }}>{t.label}</div>
                  <p className="text-sm leading-relaxed italic" style={{ color: C.textSec }}>{t.content}</p>
                </Card>
              ))}
            </div>
          </div>

          {/* Editor */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="font-display font-semibold" style={{ color: C.text }}>Sua Redação</div>
              <div className="flex items-center gap-2 text-xs">
                <Badge color={wordCount > 150 ? 'success' : wordCount > 80 ? 'gold' : 'muted'}>{wordCount} palavras</Badge>
                {wordCount >= 150 && wordCount <= 300 && <Badge color="success">✓ Tamanho ideal</Badge>}
              </div>
            </div>
            <textarea
              value={text}
              onChange={e => { setText(e.target.value); setSaved(false) }}
              placeholder="Escreva sua redação aqui... Introdução, dois parágrafos de desenvolvimento e conclusão com proposta de intervenção."
              rows={20}
              className="w-full rounded-2xl px-5 py-4 text-sm leading-relaxed resize-none outline-none"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: `1px solid ${C.borderStrong}`,
                color: C.text,
                fontFamily: "'Nunito', sans-serif",
                lineHeight: 1.8,
              }}
            />

            {/* Word guide */}
            <div className="mt-2 flex items-center gap-4 text-xs" style={{ color: C.textMuted }}>
              <span>Introdução: ~80 palavras</span>
              <span>Desenvolvimento: 2× ~100 palavras</span>
              <span>Conclusão: ~60 palavras</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-3 pb-8">
            <Btn variant="secondary" size="md" full onClick={() => { setSaved(true) }}>
              {saved ? '✓ Salvo' : '💾 SALVAR RASCUNHO'}
            </Btn>
            <Btn
              variant="primary"
              size="md"
              full
              disabled={wordCount < 50}
              style={{ background: 'linear-gradient(135deg,#ec4899,#db2777)', border: '1px solid rgba(236,72,153,0.4)', color: '#fff', boxShadow: '0 4px 16px rgba(236,72,153,0.3)' }}
            >
              ✈️ ENVIAR REDAÇÃO
            </Btn>
          </div>
        </div>
      </div>
    </div>
  )
}
