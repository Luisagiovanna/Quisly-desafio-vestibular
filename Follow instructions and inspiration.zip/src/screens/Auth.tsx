import { useState } from 'react'
import type { Screen } from '../types'
import { Btn, Input, Divider, AuthPage, Logo, Alert, C } from '../ui'

function AuthLogo() {
  return (
    <div className="flex flex-col items-center gap-4 mb-2">
      <div
        className="w-20 h-20 rounded-3xl flex items-center justify-center text-4xl flex-shrink-0"
        style={{ background: 'linear-gradient(135deg, #6366f1, #7c3aed)', boxShadow: '0 8px 32px rgba(99,102,241,0.45)' }}
      >
        🎓
      </div>
      <Logo size="lg" />
      <p className="text-sm text-center font-semibold" style={{ color: C.textMuted }}>
        Aprenda. Pratique. Conquiste seu futuro!
      </p>
    </div>
  )
}

export function LoginScreen({
  onNav,
  onLogin,
}: {
  onNav: (s: Screen) => void
  onLogin: (email: string, password: string) => Promise<void>
}) {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!email || !password) return setError('Preencha todos os campos.')
    if (!email.includes('@')) return setError('E-mail inválido.')
    if (password.length < 6) return setError('Senha muito curta.')
    setLoading(true)
    try {
      await onLogin(email, password)
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : 'Não foi possível entrar.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthPage>
      <div className="flex flex-col gap-7">
        <AuthLogo />
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <Input label="E-mail" type="email" value={email} onChange={setEmail} placeholder="seu@email.com" icon="✉️" required />
          <div>
            <Input label="Senha" type="password" value={password} onChange={setPassword} placeholder="••••••••" icon="🔒" required />
            <div className="flex justify-end mt-1.5">
              <button type="button" onClick={() => onNav('forgot')} className="text-xs font-semibold transition-colors hover:text-purple-300" style={{ color: C.primaryLight }}>
                Esqueci minha senha
              </button>
            </div>
          </div>

          {error && <Alert type="error">{error}</Alert>}

          <Btn type="submit" variant="primary" size="lg" full disabled={loading}>
            {loading ? '⏳  Entrando...' : 'ENTRAR'}
          </Btn>
        </form>

        <Divider label="OU" />

        <Btn variant="secondary" size="md" full onClick={() => {}}>
          <span className="flex items-center justify-center gap-2">
            <span className="font-bold text-base">G</span> Continuar com Google
          </span>
        </Btn>

        <p className="text-center text-sm" style={{ color: C.textMuted }}>
          Não tem conta?{' '}
          <button type="button" onClick={() => onNav('register')} className="font-bold transition-colors hover:text-amber-300" style={{ color: C.gold }}>
            Criar conta gratuita
          </button>
        </p>
        <p className="text-center text-xs" style={{ color: 'rgba(238,240,255,0.2)' }}>
          100% gratuito · Sem anúncios · Sem Premium
        </p>
      </div>
    </AuthPage>
  )
}

export function RegisterScreen({
  onNav,
  onRegister,
}: {
  onNav: (s: Screen) => void
  onRegister: (name: string, email: string, password: string) => Promise<void>
}) {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const strength = password.length === 0 ? 0 : password.length < 6 ? 1 : password.length < 10 ? 2 : password.length < 14 ? 3 : 4
  const strengthColors = ['', '#ef4444', '#f97316', '#f59e0b', '#22c55e']
  const strengthLabels = ['', 'Muito fraca', 'Fraca', 'Boa', 'Forte']

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!name || !email || !password || !confirm) return setError('Preencha todos os campos.')
    if (!email.includes('@')) return setError('E-mail inválido.')
    if (password.length < 6) return setError('Senha deve ter pelo menos 6 caracteres.')
    if (password !== confirm) return setError('As senhas não coincidem.')
    setLoading(true)
    try {
      await onRegister(name, email, password)
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : 'Não foi possível criar a conta.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <AuthPage>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl" style={{ background: 'linear-gradient(135deg,#f59e0b,#d97706)', boxShadow: '0 6px 24px rgba(245,158,11,0.4)' }}>
            ✏️
          </div>
          <Logo size="md" />
          <p className="text-sm" style={{ color: C.textMuted }}>Crie sua conta gratuita e comece sua jornada!</p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3.5">
          <Input label="Nome completo" type="text" value={name} onChange={setName} placeholder="Seu nome" icon="👤" required />
          <Input label="E-mail" type="email" value={email} onChange={setEmail} placeholder="seu@email.com" icon="✉️" required />
          <Input label="Senha" type="password" value={password} onChange={setPassword} placeholder="Mínimo 6 caracteres" icon="🔒" required />

          {password.length > 0 && (
            <div>
              <div className="flex gap-1 mb-1">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="flex-1 h-1.5 rounded-full transition-all duration-300"
                    style={{ background: i <= strength ? strengthColors[strength] : 'rgba(255,255,255,0.1)' }} />
                ))}
              </div>
              <p className="text-xs" style={{ color: strengthColors[strength] }}>{strengthLabels[strength]}</p>
            </div>
          )}

          <Input label="Confirmar senha" type="password" value={confirm} onChange={setConfirm} placeholder="Repita a senha" icon="🔑" required />

          {error && <Alert type="error">{error}</Alert>}

          <Btn type="submit" variant="gold" size="lg" full disabled={loading}>
            {loading ? '⏳  Criando conta...' : 'CRIAR CONTA GRATUITA'}
          </Btn>
        </form>

        <p className="text-center text-sm" style={{ color: C.textMuted }}>
          Já tem conta?{' '}
          <button type="button" onClick={() => onNav('login')} className="font-bold" style={{ color: C.primaryLight }}>
            Entrar
          </button>
        </p>
      </div>
    </AuthPage>
  )
}

export function ForgotScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const [email, setEmail] = useState('')
  const [sent, setSent] = useState(false)
  const [loading, setLoading] = useState(false)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!email) return
    setLoading(true)
    setTimeout(() => { setLoading(false); setSent(true) }, 1000)
  }

  return (
    <AuthPage>
      <div className="flex flex-col gap-6">
        <div className="flex flex-col items-center gap-3">
          <div className="w-16 h-16 rounded-2xl flex items-center justify-center text-3xl" style={{ background: 'linear-gradient(135deg,#3b82f6,#2563eb)', boxShadow: '0 6px 24px rgba(59,130,246,0.4)' }}>
            🔑
          </div>
          <Logo size="md" />
          <p className="text-sm text-center" style={{ color: C.textSec }}>Recuperação de senha</p>
        </div>

        {sent ? (
          <div className="flex flex-col gap-4 text-center">
            <Alert type="success">E-mail enviado! Verifique sua caixa de entrada.</Alert>
            <p className="text-sm" style={{ color: C.textSec }}>Se o e-mail não chegar em alguns minutos, verifique a pasta de spam.</p>
            <Btn variant="secondary" size="md" full onClick={() => onNav('login')}>← Voltar ao login</Btn>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <p className="text-sm text-center" style={{ color: C.textSec }}>Informe seu e-mail cadastrado e enviaremos um link para redefinir sua senha.</p>
            <Input label="E-mail" type="email" value={email} onChange={setEmail} placeholder="seu@email.com" icon="✉️" required />
            <Btn type="submit" variant="primary" size="md" full disabled={loading}>
              {loading ? '⏳  Enviando...' : 'ENVIAR LINK DE RECUPERAÇÃO'}
            </Btn>
            <Btn variant="ghost" size="sm" full onClick={() => onNav('login')}>← Voltar ao login</Btn>
          </form>
        )}
      </div>
    </AuthPage>
  )
}
