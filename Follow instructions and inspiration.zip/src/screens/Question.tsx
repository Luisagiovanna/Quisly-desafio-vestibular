import { useRef, useState } from 'react'
import type { ActivityResult, ActivityReward, Screen } from '../types'
import { sampleQuestions } from '../data'
import { achievementDefinitions } from '../progress'
import { Btn, Badge, ProgressBar, C } from '../ui'

type QuestionState = 'idle' | 'hint-open' | 'correct' | 'wrong-1' | 'wrong-2'

// ─── Option Button ────────────────────────────────────────────────
function OptionBtn({
  id, text, selected, state, correctId, onClick,
}: {
  id: string; text: string; selected: boolean; state: QuestionState; correctId: string; onClick: () => void
}) {
  const answered = state === 'correct' || state === 'wrong-2'
  const isCorrect = id === correctId
  const isSelected = selected

  let bg = 'rgba(255,255,255,0.04)'
  let border = C.border
  let labelBg = 'rgba(255,255,255,0.1)'
  let shadow = 'none'
  let textColor = C.textSec
  let labelColor = C.textMuted

  if (answered && isCorrect) {
    bg = 'rgba(34,197,94,0.12)'; border = 'rgba(34,197,94,0.4)'; labelBg = '#22c55e'
    shadow = '0 0 20px rgba(34,197,94,0.2)'; textColor = '#4ade80'; labelColor = '#fff'
  } else if (answered && isSelected && !isCorrect) {
    bg = 'rgba(239,68,68,0.12)'; border = 'rgba(239,68,68,0.4)'; labelBg = '#ef4444'
    shadow = '0 0 16px rgba(239,68,68,0.2)'; textColor = '#f87171'; labelColor = '#fff'
  } else if (!answered && isSelected) {
    bg = 'rgba(99,102,241,0.15)'; border = 'rgba(99,102,241,0.5)'; labelBg = '#6366f1'
    shadow = '0 0 20px rgba(99,102,241,0.2)'; textColor = '#c7d2fe'; labelColor = '#fff'
  }

  return (
    <button
      onClick={answered ? undefined : onClick}
      className={`flex items-start gap-3 w-full text-left rounded-xl px-4 py-3.5 transition-all ${answered ? 'cursor-default' : 'hover:brightness-110 hover:scale-[1.005]'}`}
      style={{ background: bg, border: `1px solid ${border}`, boxShadow: shadow }}
    >
      <span className="w-7 h-7 rounded-lg flex items-center justify-center font-display font-bold text-sm flex-shrink-0 mt-0.5"
        style={{ background: labelBg, color: labelColor }}>
        {id}
      </span>
      <span className="text-sm leading-relaxed flex-1" style={{ color: textColor }}>{text}</span>
      {answered && isCorrect && <span className="text-green-400 flex-shrink-0 mt-0.5">✓</span>}
      {answered && isSelected && !isCorrect && <span className="text-red-400 flex-shrink-0 mt-0.5">✗</span>}
    </button>
  )
}

// ─── Hint Modal ───────────────────────────────────────────────────
function HintModal({ hint, hintsLeft, onClose }: { hint: string; hintsLeft: number; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
      style={{ background: 'rgba(0,0,0,0.75)', backdropFilter: 'blur(8px)' }}
      onClick={onClose}
    >
      <div className="w-full max-w-sm rounded-2xl p-6 flex flex-col gap-4"
        onClick={e => e.stopPropagation()}
        style={{ background: C.bgElevated, border: '1px solid rgba(245,158,11,0.3)', boxShadow: '0 32px 80px rgba(0,0,0,0.7)' }}>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
            style={{ background: 'linear-gradient(135deg,#f59e0b,#d97706)', boxShadow: '0 4px 16px rgba(245,158,11,0.35)' }}>
            💡
          </div>
          <div>
            <div className="font-display text-lg font-semibold" style={{ color: C.text }}>Dica</div>
            <div className="text-xs" style={{ color: '#fbbf24' }}>{hintsLeft} dica{hintsLeft !== 1 ? 's' : ''} restante{hintsLeft !== 1 ? 's' : ''}</div>
          </div>
        </div>
        <div className="rounded-xl px-4 py-3 text-sm leading-relaxed"
          style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.15)', color: C.textSec }}>
          {hint}
        </div>
        <div className="flex items-center justify-between text-xs" style={{ color: C.textMuted }}>
          <span>Dica de estudo utilizada</span>
          <span>Toque fora para fechar</span>
        </div>
        <Btn variant="gold" size="md" full onClick={onClose}>Entendi! →</Btn>
      </div>
    </div>
  )
}

// ─── Feedback Section ─────────────────────────────────────────────
function FeedbackSection({ correct, explanation, onNext }: {
  correct: boolean; explanation: string; onNext: () => void
}) {
  return (
    <div className="flex flex-col gap-4 mt-4">
      {/* Result banner */}
      <div className="rounded-2xl p-4 flex flex-col gap-3"
        style={{
          background: correct ? 'rgba(34,197,94,0.1)' : 'rgba(239,68,68,0.1)',
          border: `1px solid ${correct ? 'rgba(34,197,94,0.3)' : 'rgba(239,68,68,0.3)'}`,
        }}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl flex-shrink-0"
            style={{ background: correct ? '#22c55e' : '#ef4444', boxShadow: `0 0 20px ${correct ? 'rgba(34,197,94,0.4)' : 'rgba(239,68,68,0.4)'}` }}>
            {correct ? '✓' : '✗'}
          </div>
          <div>
            <div className="font-display font-bold text-lg" style={{ color: correct ? '#4ade80' : '#f87171' }}>
              {correct ? 'Resposta Correta!' : 'Resposta Incorreta'}
            </div>
            {correct && (
              <div className="flex items-center gap-3 text-xs mt-0.5">
                <span style={{ color: '#a5b4fc' }}>+10 XP</span>
                <span style={{ color: '#fbbf24' }}>+5 🪙</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Explanation */}
      <div className="rounded-2xl p-4 flex flex-col gap-2"
        style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${C.border}` }}>
        <div className="font-display font-semibold text-sm flex items-center gap-2" style={{ color: C.primaryLight }}>
          📖 ENTENDA A RESPOSTA
        </div>
        <p className="text-sm leading-relaxed" style={{ color: C.textSec }}>{explanation}</p>
      </div>

      <Btn variant={correct ? 'success' : 'primary'} size="lg" full onClick={onNext}>
        PRÓXIMA QUESTÃO →
      </Btn>
    </div>
  )
}

// ─── Wrong-1 Section ──────────────────────────────────────────────
function WrongFirstSection({ onHint, onRetry }: { onHint: () => void; onRetry: () => void }) {
  return (
    <div className="rounded-2xl p-4 flex flex-col gap-3 mt-4"
      style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.25)' }}>
      <div className="flex items-center gap-2">
        <span className="text-2xl">🤔</span>
        <div>
          <div className="font-display font-semibold" style={{ color: '#fbbf24' }}>Ainda não!</div>
          <div className="text-sm" style={{ color: C.textSec }}>Você tem mais uma tentativa.</div>
        </div>
      </div>
      <div className="flex gap-2">
        <Btn variant="secondary" size="sm" full onClick={onHint}>💡 Ver dica</Btn>
        <Btn variant="gold" size="sm" full onClick={onRetry}>🔄 Tentar novamente</Btn>
      </div>
    </div>
  )
}

// ─── Main Question Screen ─────────────────────────────────────────
export function QuestionScreen({
  onNav,
  onComplete,
}: {
  onNav: (s: Screen) => void
  onComplete?: (result: ActivityResult) => void
}) {
  const questions = sampleQuestions
  const [qIndex, setQIndex] = useState(0)
  const [selected, setSelected] = useState<string | null>(null)
  const [state, setState] = useState<QuestionState>('idle')
  const [hintsLeft, setHintsLeft] = useState(3)
  const [hintUsed, setHintUsed] = useState(false)
  const [attempts, setAttempts] = useState(0)
  const [correctCount, setCorrectCount] = useState(0)
  const [correctStreak, setCorrectStreak] = useState(0)
  const [bestCorrectStreak, setBestCorrectStreak] = useState(0)
  const completionSubmitted = useRef(false)

  const q = questions[qIndex % questions.length]
  const totalQ = 10

  function handleSelect(id: string) {
    if (state !== 'idle') return
    setSelected(id)
  }

  function handleConfirm() {
    if (!selected || state !== 'idle') return
    const isCorrect = selected === q.correct
    setAttempts(a => a + 1)
    if (isCorrect) {
      setState('correct')
      setCorrectCount(c => c + 1)
      setCorrectStreak(streak => {
        const nextStreak = streak + 1
        setBestCorrectStreak(best => Math.max(best, nextStreak))
        return nextStreak
      })
    } else if (attempts === 0) {
      setState('wrong-1')
    } else {
      setState('wrong-2')
      setCorrectStreak(0)
    }
  }

  function handleHint() {
    if (!hintUsed) {
      setHintsLeft(n => Math.max(0, n - 1))
      setHintUsed(true)
    }
    setState('hint-open')
  }

  function handleRetry() {
    setSelected(null)
    setState('idle')
  }

  function handleNext() {
    if (qIndex + 1 >= totalQ) {
      if (completionSubmitted.current) return
      completionSubmitted.current = true
      onComplete?.({ correct: correctCount, total: totalQ, bestCorrectStreak })
      onNav('phase-result')
      return
    }
    setQIndex(i => i + 1)
    setSelected(null)
    setState('idle')
    setAttempts(0)
    setHintUsed(false)
  }

  const answered = state === 'correct' || state === 'wrong-2'
  const progressPct = ((qIndex) / totalQ) * 100

  return (
    <div className="flex flex-col min-h-screen" style={{ background: C.bgDeep }}>
      {state === 'hint-open' && (
        <HintModal hint={q.hint} hintsLeft={hintsLeft} onClose={() => setState('idle')} />
      )}

      {/* Header */}
      <div className="flex-shrink-0" style={{ background: C.bgSurface, borderBottom: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-3 px-4 py-3">
          <button onClick={() => onNav('subject-map')} className="w-8 h-8 rounded-lg flex items-center justify-center transition-all hover:bg-white/8" style={{ color: C.textSec }}>←</button>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <Badge color="primary" size="xs">{q.theme}</Badge>
                <span className="text-xs" style={{ color: C.textMuted }}>{q.subtheme}</span>
              </div>
              <div className="flex items-center gap-3 text-xs" style={{ color: C.textMuted }}>
                <span style={{ color: hintsLeft > 0 ? '#fbbf24' : C.textMuted }}>💡 {hintsLeft}</span>
                <span>{qIndex + 1}/{totalQ}</span>
              </div>
            </div>
            <ProgressBar value={qIndex} max={totalQ} color={`linear-gradient(90deg, #6366f1, #a78bfa)`} height={6} animated />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-4" style={{ paddingBottom: 120 }}>
        {/* Support text */}
        {q.supportText && (
          <div className="rounded-2xl p-4 flex flex-col gap-2"
            style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${C.border}` }}>
            {q.source && (
              <div className="text-xs font-semibold uppercase tracking-wide" style={{ color: C.textMuted }}>Texto de Apoio</div>
            )}
            <p className="text-sm leading-relaxed italic" style={{ color: C.textSec }}>{q.supportText}</p>
            {q.source && (
              <p className="text-xs" style={{ color: C.textMuted }}>{q.source}</p>
            )}
          </div>
        )}

        {/* Statement */}
        <div>
          <p className="font-semibold leading-relaxed" style={{ color: C.text }}>{q.statement}</p>
        </div>

        {/* Options */}
        <div className="flex flex-col gap-2.5">
          {q.options.map(opt => (
            <OptionBtn
              key={opt.id}
              id={opt.id}
              text={opt.text}
              selected={selected === opt.id}
              state={state}
              correctId={q.correct}
              onClick={() => handleSelect(opt.id)}
            />
          ))}
        </div>

        {/* Wrong-1 feedback */}
        {state === 'wrong-1' && (
          <WrongFirstSection onHint={handleHint} onRetry={handleRetry} />
        )}

        {/* Final feedback */}
        {answered && (
          <FeedbackSection
            correct={state === 'correct'}
            explanation={q.explanation}
            onNext={handleNext}
          />
        )}
      </div>

      {/* Footer (only in idle/hint state) */}
      {(state === 'idle') && (
        <div className="fixed bottom-0 left-0 right-0 px-4 py-4 flex gap-3 md:sticky md:bottom-auto"
          style={{ background: C.bgSurface, borderTop: `1px solid ${C.border}`, paddingBottom: 'max(16px, env(safe-area-inset-bottom))' }}>
          <Btn
            variant="secondary"
            size="md"
            onClick={handleHint}
            disabled={hintsLeft === 0}
            style={{ gap: 4 }}
          >
            <span>💡</span>
            <span className="inline-flex items-center justify-center w-5 h-5 rounded-full text-xs font-bold ml-1"
              style={{ background: hintsLeft > 0 ? '#f59e0b' : 'rgba(255,255,255,0.1)', color: '#fff' }}>
              {hintsLeft}
            </span>
            {' '}DICA
          </Btn>
          <Btn
            variant={selected ? 'success' : 'ghost'}
            size="md"
            full
            onClick={handleConfirm}
            disabled={!selected}
          >
            CONFIRMAR RESPOSTA
          </Btn>
        </div>
      )}
    </div>
  )
}

// ─── Phase Result Screen ──────────────────────────────────────────
export function PhaseResultScreen({
  onNav,
  reward,
}: {
  onNav: (s: Screen) => void
  reward: ActivityReward | null
}) {
  const correct = reward?.correct ?? 0
  const total = reward?.total ?? 10
  const pct = Math.round((correct / total) * 100)
  const stars = reward?.stars ?? 0
  const xp = reward?.xp ?? 0
  const coins = reward?.totalCoins ?? 0
  const newAchievements = achievementDefinitions.filter(achievement => (
    reward?.unlockedAchievements.includes(achievement.id)
  ))

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 py-10"
      style={{ background: `radial-gradient(ellipse at 50% 30%, rgba(99,102,241,0.15) 0%, ${C.bgDeep} 60%)` }}>
      <div className="w-full max-w-sm flex flex-col gap-6 text-center">
        {/* Stars */}
        <div>
          <div className="flex justify-center gap-3 mb-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <span key={i} className="text-5xl transition-all"
                style={{ color: i < stars ? C.gold : 'rgba(255,255,255,0.12)', filter: i < stars ? 'drop-shadow(0 0 8px rgba(245,158,11,0.6))' : 'none' }}>
                ★
              </span>
            ))}
          </div>
          <h2 className="font-display text-3xl font-bold" style={{ color: C.text }}>Fase Concluída!</h2>
          <p className="text-base mt-1" style={{ color: C.textSec }}>
            {pct >= 80 ? 'Você dominou este conteúdo! 🎉' : pct >= 60 ? 'Bom resultado! Continue assim.' : 'Vale revisar alguns pontos antes de continuar.'}
          </p>
        </div>

        {/* Score */}
        <div className="rounded-2xl p-5" style={{ background: C.bgCard, border: `1px solid ${C.border}` }}>
          <div className="font-display text-5xl font-bold mb-1" style={{ color: pct >= 70 ? C.success : pct >= 50 ? C.gold : C.error }}>
            {correct}/{total}
          </div>
          <div className="text-sm" style={{ color: C.textMuted }}>{pct}% de acertos</div>

          <div className="h-px w-full my-4" style={{ background: C.border }} />

          <div className="flex justify-around">
            {[
              { icon: '⭐', label: '+' + xp + ' XP', color: C.primaryLight },
              { icon: '🪙', label: '+' + coins, color: C.gold },
              { icon: '🏅', label: `${newAchievements.length} novas`, color: C.textSec },
            ].map(s => (
              <div key={s.label} className="flex flex-col items-center gap-1">
                <span className="text-2xl">{s.icon}</span>
                <span className="font-bold text-sm" style={{ color: s.color }}>{s.label}</span>
              </div>
            ))}
          </div>
        </div>

        {newAchievements.length > 0 && (
          <div className="rounded-2xl p-4 text-left flex flex-col gap-3"
            style={{ background: 'rgba(245,158,11,0.09)', border: '1px solid rgba(245,158,11,0.25)' }}>
            <div className="font-display font-bold" style={{ color: C.goldLight }}>
              Conquistas desbloqueadas
            </div>
            {newAchievements.map(achievement => (
              <div key={achievement.id} className="flex items-center gap-3">
                <span className="text-2xl">{achievement.icon}</span>
                <div className="flex-1">
                  <div className="text-sm font-bold" style={{ color: C.text }}>{achievement.title}</div>
                  <div className="text-xs" style={{ color: C.textMuted }}>{achievement.desc}</div>
                </div>
                <Badge color="gold">+{achievement.reward} 🪙</Badge>
              </div>
            ))}
          </div>
        )}

        {/* Buttons */}
        <div className="flex flex-col gap-2.5">
          <Btn variant="gold" size="lg" full onClick={() => onNav('question')}>PRÓXIMA FASE →</Btn>
          <Btn variant="secondary" size="md" full onClick={() => onNav('question')}>🔍 Revisar Erros</Btn>
          <Btn variant="ghost" size="md" full onClick={() => onNav('subject-map')}>← Voltar ao Mapa</Btn>
        </div>
      </div>
    </div>
  )
}
