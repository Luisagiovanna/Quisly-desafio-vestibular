import type { Screen, User } from '../types'
import { Card, Btn, Avatar, LeagueBadge, StatChip, XPBar, C, SectionTitle } from '../ui'
import { subjectMeta } from '../data'

export function HomeScreen({ user, onNav }: { user: User; onNav: (s: Screen) => void }) {
  return (
    <div className="flex flex-col">
      {/* Mobile Header */}
      <div className="md:hidden px-4 pt-4 pb-3 flex items-center justify-between" style={{ background: C.bgSurface, borderBottom: `1px solid ${C.border}` }}>
        <div className="flex items-center gap-3">
          <Avatar name={user.name} size={40} level={user.level} avatar={user.avatar} />
          <div>
            <div className="text-sm font-bold" style={{ color: C.text }}>Olá, {user.name}! 👋</div>
            <LeagueBadge league={user.league} size="xs" />
          </div>
        </div>
        <div className="flex items-center gap-3 text-sm">
          <StatChip icon="🔥" value={`${user.streak}d`} color="#fb923c" />
          <StatChip icon="🪙" value={user.coins} color={C.gold} />
        </div>
      </div>

      <div className="px-4 py-5 flex flex-col gap-6 max-w-4xl w-full mx-auto">
        {/* Desktop greeting */}
        <div className="hidden md:flex items-center justify-between">
          <div>
            <h1 className="font-display text-3xl font-bold" style={{ color: C.text }}>Olá, {user.name}! 👋</h1>
            <p className="text-sm mt-0.5" style={{ color: C.textSec }}>Pronto para mais um dia de estudos?</p>
          </div>
          <div className="flex items-center gap-4">
            <StatChip icon="⭐" value={user.xp.toLocaleString()} label="XP" color={C.primaryLight} />
            <StatChip icon="🪙" value={user.coins} label="moedas" color={C.gold} />
            <StatChip icon="🔥" value={`${user.streak} dias`} label="seguidos" color="#fb923c" />
            <LeagueBadge league={user.league} size="md" />
          </div>
        </div>

        {/* XP Bar (desktop) */}
        <div className="hidden md:block">
          <XPBar xp={user.xp} level={user.level} />
        </div>

        {/* Today's challenge */}
        <Card elevated glow="rgba(99,102,241,0.12)" padding="p-0">
          <div className="p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="text-amber-400 text-lg">🎯</span>
                <span className="text-xs font-bold uppercase tracking-wider" style={{ color: C.primaryLight }}>Seu Desafio de Hoje</span>
              </div>
              <h3 className="font-display text-xl font-semibold mb-1" style={{ color: C.text }}>Reforce Geopolítica</h3>
              <p className="text-sm" style={{ color: C.textSec }}>
                Sua taxa de acertos neste tópico é de <strong style={{ color: C.error }}>51%</strong>. Vamos melhorar!
              </p>
              <div className="flex items-center gap-4 mt-2.5 text-xs" style={{ color: C.textMuted }}>
                <span>📝 10 questões</span>
                <span>⏱️ ≈ 12 minutos</span>
                <span>+80 XP</span>
              </div>
            </div>
            <Btn variant="gold" size="lg" onClick={() => onNav('question')}>
              ▶ COMEÇAR
            </Btn>
          </div>
        </Card>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { icon: '📝', value: '347', label: 'Questões', color: C.primaryLight },
            { icon: '✅', value: '74%', label: 'Taxa de acerto', color: C.success },
            { icon: '🔥', value: `${user.streak}`, label: 'Dias seguidos', color: '#fb923c' },
            { icon: '📊', value: '3', label: 'Simulados', color: C.blue },
          ].map(s => (
            <Card key={s.label} padding="p-4">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="font-display text-2xl font-bold" style={{ color: s.color }}>{s.value}</div>
              <div className="text-xs" style={{ color: C.textMuted }}>{s.label}</div>
            </Card>
          ))}
        </div>

        {/* Main navigation grid */}
        <div>
          <SectionTitle>O que deseja fazer?</SectionTitle>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[
              { icon: '🗺️', label: 'Jornada', sub: '4 matérias · 28 fases', screen: 'journey' as Screen, gradient: 'linear-gradient(135deg,#6366f1,#4f46e5)', glow: 'rgba(99,102,241,0.25)' },
              { icon: '✍️', label: 'Redação', sub: '9 competências', screen: 'essay-hub' as Screen, gradient: 'linear-gradient(135deg,#ec4899,#db2777)', glow: 'rgba(236,72,153,0.2)' },
              { icon: '📝', label: 'Simulados', sub: 'Rápido ou completo', screen: 'simulations' as Screen, gradient: 'linear-gradient(135deg,#3b82f6,#2563eb)', glow: 'rgba(59,130,246,0.2)' },
              { icon: '📊', label: 'Desempenho', sub: 'Sua evolução', screen: 'performance' as Screen, gradient: 'linear-gradient(135deg,#22c55e,#16a34a)', glow: 'rgba(34,197,94,0.2)' },
              { icon: '🏆', label: 'Ranking', sub: 'Liga Prata • Pos. 6', screen: 'ranking' as Screen, gradient: 'linear-gradient(135deg,#f59e0b,#d97706)', glow: 'rgba(245,158,11,0.2)' },
              { icon: '👤', label: 'Perfil', sub: 'Conquistas e avatar', screen: 'profile' as Screen, gradient: 'linear-gradient(135deg,#a78bfa,#7c3aed)', glow: 'rgba(167,139,250,0.2)' },
            ].map(item => (
              <Card key={item.label} onClick={() => onNav(item.screen)} glow={item.glow} padding="p-0">
                <div className="p-4 flex flex-col gap-2">
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl"
                    style={{ background: item.gradient }}
                  >
                    {item.icon}
                  </div>
                  <div>
                    <div className="font-display font-semibold text-base" style={{ color: C.text }}>{item.label}</div>
                    <div className="text-xs" style={{ color: C.textMuted }}>{item.sub}</div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* Subject progress */}
        <div>
          <SectionTitle action={<Btn variant="ghost" size="xs" onClick={() => onNav('performance')}>Ver tudo</Btn>}>
            Progresso por Matéria
          </SectionTitle>
          <div className="flex flex-col gap-2.5">
            {(Object.entries(subjectMeta) as [keyof typeof subjectMeta, typeof subjectMeta[keyof typeof subjectMeta]][]).map(([key, m]) => {
              const pcts: Record<string, number> = { history: 68, geography: 51, philosophy: 79, sociology: 43, language: 88 }
              const pct = pcts[key] ?? 50
              return (
                <Card key={key} padding="p-3" onClick={() => onNav('journey')}>
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl flex items-center justify-center text-lg flex-shrink-0" style={{ background: m.bgGlow }}>
                      {m.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-semibold" style={{ color: C.text }}>{m.label}</span>
                        <span className="text-sm font-bold" style={{ color: m.color }}>{pct}%</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.07)' }}>
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, background: m.gradient }} />
                      </div>
                    </div>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}
