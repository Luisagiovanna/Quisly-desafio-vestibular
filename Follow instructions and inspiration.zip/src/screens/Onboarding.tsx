import { useState } from 'react'
import type { User } from '../types'
import { Btn, Input, AuthPage, Logo, C } from '../ui'

const steps = ['name', 'year', 'language', 'course', 'ready'] as const
type Step = typeof steps[number]

const yearOptions = ['1º ano', '2º ano', '3º ano', 'Formado(a)', 'Cursinho']
const courseOptions = ['Medicina', 'Direito', 'Engenharia', 'Psicologia', 'Arquitetura', 'Administração', 'Computação', 'Educação', 'Ainda não sei', 'Outro']

export function OnboardingScreen({
  user,
  onComplete,
}: {
  user: User
  onComplete: (profile: Pick<User, 'name' | 'language' | 'course' | 'university'>) => void
}) {
  const [step, setStep] = useState<Step>('name')
  const [name, setName] = useState(user.name)
  const [year, setYear] = useState('')
  const [lang, setLang] = useState<'english' | 'spanish' | ''>('')
  const [course, setCourse] = useState('')
  const [university, setUniversity] = useState('')

  const stepIdx = steps.indexOf(step)
  const progress = ((stepIdx) / (steps.length - 1)) * 100

  function next() {
    const nextStep = steps[stepIdx + 1]
    if (nextStep) setStep(nextStep)
    else finish()
  }

  function finish() {
    onComplete({
      name: name.trim(),
      language: lang || user.language,
      course: course || undefined,
      university: university.trim() || undefined,
    })
  }

  return (
    <AuthPage>
      <div className="flex flex-col gap-8">
        {/* Header */}
        <div className="flex flex-col items-center gap-2">
          <Logo size="md" />
          <div className="w-full mt-4">
            <div className="flex justify-between text-xs mb-1.5" style={{ color: C.textMuted }}>
              <span>Configurando seu perfil</span>
              <span>{stepIdx + 1} / {steps.length}</span>
            </div>
            <div className="h-1.5 w-full rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
              <div className="h-full rounded-full transition-all duration-500" style={{ width: `${progress}%`, background: 'linear-gradient(90deg, #6366f1, #a78bfa)' }} />
            </div>
          </div>
        </div>

        {/* Step: name */}
        {step === 'name' && (
          <div className="flex flex-col gap-6">
            <div className="text-center">
              <div className="text-4xl mb-3">👋</div>
              <h2 className="font-display text-2xl font-semibold" style={{ color: C.text }}>Como podemos chamar você?</h2>
              <p className="text-sm mt-1" style={{ color: C.textMuted }}>Use o nome ou apelido que preferir.</p>
            </div>
            <Input label="" type="text" value={name} onChange={setName} placeholder="Seu nome ou apelido" icon="✏️" />
            <Btn variant="primary" size="lg" full onClick={next} disabled={!name.trim()}>Continuar →</Btn>
          </div>
        )}

        {/* Step: year */}
        {step === 'year' && (
          <div className="flex flex-col gap-6">
            <div className="text-center">
              <div className="text-4xl mb-3">📚</div>
              <h2 className="font-display text-2xl font-semibold" style={{ color: C.text }}>Em que ano você está?</h2>
              <p className="text-sm mt-1" style={{ color: C.textMuted }}>Assim personalizamos sua jornada de estudos.</p>
            </div>
            <div className="grid grid-cols-2 gap-2.5">
              {yearOptions.map(y => (
                <button key={y} onClick={() => setYear(y)}
                  className="py-3 px-4 rounded-xl font-semibold text-sm transition-all hover:scale-[1.02]"
                  style={{
                    background: year === y ? 'linear-gradient(135deg,#6366f1,#4f46e5)' : 'rgba(255,255,255,0.05)',
                    border: `1px solid ${year === y ? 'rgba(99,102,241,0.5)' : C.border}`,
                    color: year === y ? '#fff' : C.textSec,
                    boxShadow: year === y ? '0 4px 16px rgba(99,102,241,0.3)' : 'none',
                  }}>
                  {y}
                </button>
              ))}
            </div>
            <Btn variant="primary" size="lg" full onClick={next} disabled={!year}>Continuar →</Btn>
          </div>
        )}

        {/* Step: language */}
        {step === 'language' && (
          <div className="flex flex-col gap-6">
            <div className="text-center">
              <div className="text-4xl mb-3">🌐</div>
              <h2 className="font-display text-2xl font-semibold" style={{ color: C.text }}>Qual língua estrangeira você escolheu para o ENEM?</h2>
              <p className="text-sm mt-1" style={{ color: C.textMuted }}>Você pode alterar isso depois nas configurações.</p>
            </div>
            <div className="flex flex-col gap-3">
              {[
                { key: 'english' as const, label: '🇺🇸 Inglês', desc: 'English' },
                { key: 'spanish' as const, label: '🇪🇸 Espanhol', desc: 'Español' },
              ].map(l => (
                <button key={l.key} onClick={() => setLang(l.key)}
                  className="flex items-center justify-between py-4 px-5 rounded-xl transition-all hover:scale-[1.01]"
                  style={{
                    background: lang === l.key ? 'rgba(99,102,241,0.2)' : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${lang === l.key ? 'rgba(99,102,241,0.5)' : C.border}`,
                    boxShadow: lang === l.key ? '0 0 20px rgba(99,102,241,0.2)' : 'none',
                  }}>
                  <div className="text-left">
                    <div className="font-bold" style={{ color: C.text }}>{l.label}</div>
                    <div className="text-xs" style={{ color: C.textMuted }}>{l.desc}</div>
                  </div>
                  {lang === l.key && <span className="text-lg">✓</span>}
                </button>
              ))}
            </div>
            <Btn variant="primary" size="lg" full onClick={next} disabled={!lang}>Continuar →</Btn>
          </div>
        )}

        {/* Step: course */}
        {step === 'course' && (
          <div className="flex flex-col gap-6">
            <div className="text-center">
              <div className="text-4xl mb-3">🎯</div>
              <h2 className="font-display text-2xl font-semibold" style={{ color: C.text }}>Qual curso você pretende fazer?</h2>
              <p className="text-sm mt-1" style={{ color: C.textMuted }}>Isso nos ajuda a personalizar seu conteúdo.</p>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {courseOptions.map(c => (
                <button key={c} onClick={() => setCourse(c)}
                  className="py-2.5 px-3 rounded-xl text-sm font-semibold text-left transition-all hover:scale-[1.01]"
                  style={{
                    background: course === c ? 'rgba(245,158,11,0.2)' : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${course === c ? 'rgba(245,158,11,0.45)' : C.border}`,
                    color: course === c ? C.goldLight : C.textSec,
                  }}>
                  {c}
                </button>
              ))}
            </div>
            <Input label="Universidade (opcional)" type="text" value={university} onChange={setUniversity} placeholder="Ex: USP, UNICAMP, UFRJ..." icon="🏛️" />
            <div className="flex gap-2">
              <Btn variant="ghost" size="md" full onClick={next}>Pular</Btn>
              <Btn variant="gold" size="md" full onClick={next} disabled={!course}>Continuar →</Btn>
            </div>
          </div>
        )}

        {/* Step: ready */}
        {step === 'ready' && (
          <div className="flex flex-col gap-7 text-center">
            <div>
              <div className="text-6xl mb-4">🚀</div>
              <h2 className="font-display text-2xl font-bold mb-2" style={{ color: C.text }}>
                Tudo pronto, {name || 'estudante'}!
              </h2>
              <p className="text-sm" style={{ color: C.textSec }}>
                Sua jornada rumo ao ENEM começa agora. Estude todos os dias, acumule XP e conquiste o topo do ranking!
              </p>
            </div>
            <div className="flex flex-col gap-2.5">
              {[
                { icon: '🗺️', text: 'Explore os 4 territórios de Ciências Humanas' },
                { icon: '⭐', text: 'Ganhe estrelas e XP respondendo questões' },
                { icon: '🏆', text: 'Suba nas ligas e dispute com outros estudantes' },
                { icon: '✍️', text: 'Treine sua redação com temas do ENEM' },
              ].map(item => (
                <div key={item.text} className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm text-left"
                  style={{ background: 'rgba(255,255,255,0.04)', border: `1px solid ${C.border}` }}>
                  <span className="text-xl flex-shrink-0">{item.icon}</span>
                  <span style={{ color: C.textSec }}>{item.text}</span>
                </div>
              ))}
            </div>
            <Btn variant="gold" size="xl" full onClick={finish}>
              🎮 COMEÇAR DESAFIO
            </Btn>
          </div>
        )}
      </div>
    </AuthPage>
  )
}
