import { useState } from 'react'
import type { Screen } from '../types'
import { Card, Badge, LeagueBadge, Avatar, Page, C, SectionTitle } from '../ui'
import { leaderboard } from '../data'

type RankTab = 'geral' | 'semanal' | 'liga' | 'amigos'

const leagueZones = {
  promotion: [1, 2, 3],
  safe: [4, 5, 6, 7],
  relegation: [8, 9, 10],
}

export function RankingScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const [tab, setTab] = useState<RankTab>('liga')

  const medals: Record<number, string> = { 1: '🥇', 2: '🥈', 3: '🥉' }

  function getZoneStyle(pos: number) {
    if (leagueZones.promotion.includes(pos)) return { borderLeft: '3px solid rgba(34,197,94,0.6)', background: 'rgba(34,197,94,0.04)' }
    if (leagueZones.relegation.includes(pos)) return { borderLeft: '3px solid rgba(239,68,68,0.4)', background: 'rgba(239,68,68,0.03)' }
    return {}
  }

  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-5 max-w-3xl mx-auto">
        <div>
          <h1 className="font-display text-2xl font-bold" style={{ color: C.text }}>🏆 Ranking</h1>
          <p className="text-sm mt-1" style={{ color: C.textSec }}>Compete com outros estudantes e suba de liga!</p>
        </div>

        {/* League info */}
        <Card elevated padding="p-4" style={{ background: 'linear-gradient(135deg,rgba(148,163,184,0.08),rgba(99,102,241,0.06))', border: '1px solid rgba(148,163,184,0.2)' }}>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-xs font-semibold uppercase tracking-wide mb-1" style={{ color: '#94a3b8' }}>Sua Liga Atual</div>
              <div className="flex items-center gap-2">
                <span className="text-3xl">🥈</span>
                <div>
                  <div className="font-display text-xl font-bold" style={{ color: '#94a3b8' }}>Liga Prata</div>
                  <div className="text-xs" style={{ color: C.textMuted }}>Reset em 5 dias</div>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs" style={{ color: C.textMuted }}>Sua posição</div>
              <div className="font-display text-3xl font-bold" style={{ color: C.primaryLight }}>6°</div>
              <div className="text-xs" style={{ color: C.success }}>↑ 2 posições esta semana</div>
            </div>
          </div>
          {/* Zone legend */}
          <div className="flex gap-3 mt-3">
            <div className="flex items-center gap-1.5 text-xs" style={{ color: C.success }}>
              <div className="w-2 h-2 rounded-sm" style={{ background: C.success }} />
              Promoção (Top 3)
            </div>
            <div className="flex items-center gap-1.5 text-xs" style={{ color: C.error }}>
              <div className="w-2 h-2 rounded-sm" style={{ background: C.error }} />
              Rebaixamento (8-10)
            </div>
          </div>
        </Card>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl" style={{ background: 'rgba(255,255,255,0.05)' }}>
          {([
            { id: 'liga' as RankTab, label: 'Minha Liga' },
            { id: 'geral' as RankTab, label: 'Geral' },
            { id: 'semanal' as RankTab, label: 'Semanal' },
            { id: 'amigos' as RankTab, label: 'Amigos' },
          ]).map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className="flex-1 py-2 rounded-lg text-xs font-bold transition-all"
              style={{
                background: tab === t.id ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'transparent',
                color: tab === t.id ? '#fff' : C.textMuted,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Header row */}
        <div className="flex items-center px-4 text-xs font-bold uppercase tracking-wider" style={{ color: C.textMuted }}>
          <span style={{ width: 40 }}>Pos.</span>
          <span className="flex-1">Jogador</span>
          <span style={{ width: 48 }} className="text-center">Nível</span>
          <span style={{ width: 72 }} className="text-right">Pontos</span>
        </div>

        {/* Leaderboard */}
        <div className="flex flex-col gap-2">
          {leaderboard.map((row) => (
            <div
              key={row.pos}
              className="flex items-center gap-3 rounded-2xl px-4 py-3 transition-all"
              style={{
                background: row.isMe ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.03)',
                border: row.isMe ? '1px solid rgba(99,102,241,0.4)' : `1px solid ${C.border}`,
                boxShadow: row.isMe ? '0 0 20px rgba(99,102,241,0.12)' : 'none',
                ...getZoneStyle(row.pos),
              }}
            >
              {/* Position */}
              <div style={{ width: 36 }} className="text-center flex-shrink-0">
                {medals[row.pos]
                  ? <span className="text-xl">{medals[row.pos]}</span>
                  : <span className="font-display font-bold text-sm" style={{ color: row.isMe ? C.primaryLight : C.textMuted }}>{row.pos}</span>
                }
              </div>
              {/* Avatar */}
              <Avatar name={row.name} size={36} />
              {/* Name */}
              <div className="flex-1 min-w-0">
                <div className="font-semibold text-sm" style={{ color: row.isMe ? C.primaryLight : C.text }}>{row.name}</div>
                <LeagueBadge league={row.league} size="xs" />
              </div>
              {/* Level */}
              <div style={{ width: 48 }} className="text-center flex-shrink-0">
                <span className="px-2 py-0.5 rounded-lg font-bold text-xs text-white" style={{ background: 'rgba(99,102,241,0.4)' }}>{row.level}</span>
              </div>
              {/* Score */}
              <div style={{ width: 72 }} className="text-right flex-shrink-0">
                <span className="font-display font-bold text-sm" style={{ color: row.isMe ? C.gold : C.text }}>
                  {row.score.toLocaleString()}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* League system */}
        <div>
          <SectionTitle>Sistema de Ligas</SectionTitle>
          <div className="grid grid-cols-5 gap-2">
            {[
              { icon: '🥉', label: 'Bronze', color: '#d97706' },
              { icon: '🥈', label: 'Prata', color: '#94a3b8', active: true },
              { icon: '🥇', label: 'Ouro', color: '#f59e0b' },
              { icon: '💎', label: 'Diamante', color: '#67e8f9' },
              { icon: '👑', label: 'Mestre', color: '#a78bfa' },
            ].map(l => (
              <div key={l.label} className="flex flex-col items-center gap-1 p-2 rounded-xl transition-all"
                style={{
                  background: l.active ? `${l.color}18` : 'rgba(255,255,255,0.03)',
                  border: `1px solid ${l.active ? l.color + '44' : C.border}`,
                }}>
                <span className="text-xl">{l.icon}</span>
                <span className="text-[10px] font-bold" style={{ color: l.active ? l.color : C.textMuted }}>{l.label}</span>
                {l.active && <span className="text-[9px]" style={{ color: l.color }}>Você</span>}
              </div>
            ))}
          </div>
        </div>
      </div>
    </Page>
  )
}
