import { useState } from 'react'
import type { Screen } from '../types'
import { Card, Btn, Input, Select, Textarea, Badge, BackHeader, C, SectionTitle, Divider } from '../ui'
import { subjectMeta } from '../data'

// ─── Admin Dashboard ──────────────────────────────────────────────
export function AdminDashboard({ onNav }: { onNav: (s: Screen) => void }) {
  const stats = [
    { icon: '👤', label: 'Usuários Ativos', val: '1.284', change: '+12%', color: C.primaryLight },
    { icon: '📝', label: 'Questões Respondidas', val: '84.210', change: '+8%', color: C.success },
    { icon: '✅', label: 'Taxa Média de Acertos', val: '67%', change: '+3%', color: C.gold },
    { icon: '📋', label: 'Simulados Realizados', val: '342', change: '+15%', color: C.blue },
    { icon: '✍️', label: 'Redações Enviadas', val: '89', change: '+5%', color: '#f472b6' },
    { icon: '🔥', label: 'Sequência Média', val: '4.2 dias', change: '+0.5', color: '#fb923c' },
  ]

  const sections = [
    { id: 'questoes', icon: '📝', label: 'Questões', count: 428 },
    { id: 'materias', icon: '📚', label: 'Matérias', count: 5 },
    { id: 'temas', icon: '🗂️', label: 'Temas', count: 14 },
    { id: 'fases', icon: '🎮', label: 'Fases', count: 51 },
    { id: 'redacoes', icon: '✍️', label: 'Temas de Redação', count: 12 },
    { id: 'usuarios', icon: '👥', label: 'Usuários', count: 1284 },
  ]

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#060914' }}>
      {/* Admin Header */}
      <div className="flex items-center justify-between px-6 py-4" style={{ background: '#0c1024', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
        <div>
          <div className="font-display text-lg font-bold" style={{ color: C.text }}>🔧 Painel Administrativo</div>
          <div className="text-xs" style={{ color: C.textMuted }}>Desafio Vestibular</div>
        </div>
        <Btn variant="ghost" size="sm" onClick={() => onNav('home')}>← Voltar ao App</Btn>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 max-w-6xl mx-auto w-full">
        {/* Dashboard stats */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
          {stats.map(s => (
            <Card key={s.label} padding="p-5" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.06)' }}>
              <div className="flex items-center justify-between mb-3">
                <span className="text-xl">{s.icon}</span>
                <span className="text-xs font-bold px-1.5 py-0.5 rounded-md" style={{ background: 'rgba(34,197,94,0.15)', color: C.success }}>{s.change}</span>
              </div>
              <div className="font-display text-2xl font-bold mb-0.5" style={{ color: s.color }}>{s.val}</div>
              <div className="text-xs" style={{ color: C.textMuted }}>{s.label}</div>
            </Card>
          ))}
        </div>

        {/* Management sections */}
        <SectionTitle>Gerenciamento de Conteúdo</SectionTitle>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-8">
          {sections.map(s => (
            <Card
              key={s.id}
              padding="p-4"
              style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.06)', cursor: 'pointer' }}
              onClick={s.id === 'questoes' ? () => onNav('admin-question') : undefined}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-2xl">{s.icon}</span>
                <span className="font-bold text-sm" style={{ color: C.primaryLight }}>{s.count}</span>
              </div>
              <div className="font-semibold text-sm" style={{ color: C.text }}>{s.label}</div>
              {s.id === 'questoes' && (
                <div className="text-xs mt-0.5" style={{ color: C.textMuted }}>Clique para gerenciar</div>
              )}
            </Card>
          ))}
        </div>

        {/* Recent questions */}
        <SectionTitle action={<Btn variant="primary" size="sm" onClick={() => onNav('admin-question')}>+ Nova Questão</Btn>}>
          Questões Recentes
        </SectionTitle>
        <div className="flex flex-col gap-2 mb-8">
          {[
            { id: 'Q-428', subject: 'history', theme: 'Era Vargas', diff: 'medium', status: 'published' },
            { id: 'Q-427', subject: 'geography', theme: 'Geopolítica', diff: 'easy', status: 'review' },
            { id: 'Q-426', subject: 'philosophy', theme: 'Contratualismo', diff: 'hard', status: 'draft' },
            { id: 'Q-425', subject: 'sociology', theme: 'Movimentos Sociais', diff: 'medium', status: 'published' },
          ].map(q => {
            const m = subjectMeta[q.subject as keyof typeof subjectMeta]
            const statusMap: Record<string, { label: string; color: string }> = {
              published: { label: 'Publicada', color: 'success' },
              review: { label: 'Em Revisão', color: 'gold' },
              draft: { label: 'Rascunho', color: 'muted' },
              archived: { label: 'Arquivada', color: 'error' },
            }
            const s = statusMap[q.status]
            return (
              <Card key={q.id} padding="p-4" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono" style={{ color: C.textMuted }}>{q.id}</span>
                  <span className="text-base">{m.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-semibold" style={{ color: C.text }}>{m.label} – {q.theme}</div>
                  </div>
                  <Badge color={q.diff === 'easy' ? 'success' : q.diff === 'medium' ? 'gold' : 'error'} size="xs">
                    {q.diff === 'easy' ? 'Fácil' : q.diff === 'medium' ? 'Médio' : 'Difícil'}
                  </Badge>
                  <Badge color={s.color} size="xs">{s.label}</Badge>
                  <Btn variant="ghost" size="xs" onClick={() => onNav('admin-question')}>✏️</Btn>
                </div>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}

// ─── Admin Question Form ──────────────────────────────────────────
type FormStatus = 'draft' | 'review' | 'published' | 'archived'

export function AdminQuestionForm({ onNav }: { onNav: (s: Screen) => void }) {
  const [subject, setSubject] = useState('')
  const [theme, setTheme] = useState('')
  const [subtheme, setSubtheme] = useState('')
  const [difficulty, setDifficulty] = useState('')
  const [year, setYear] = useState('')
  const [supportText, setSupportText] = useState('')
  const [source, setSource] = useState('')
  const [statement, setStatement] = useState('')
  const [optA, setOptA] = useState('')
  const [optB, setOptB] = useState('')
  const [optC, setOptC] = useState('')
  const [optD, setOptD] = useState('')
  const [optE, setOptE] = useState('')
  const [correct, setCorrect] = useState('')
  const [hint, setHint] = useState('')
  const [explanation, setExplanation] = useState('')
  const [status, setStatus] = useState<FormStatus>('draft')

  const subjectOptions = Object.entries(subjectMeta).map(([k, m]) => ({ value: k, label: `${m.icon} ${m.label}` }))

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#060914' }}>
      <BackHeader onBack={() => onNav('admin')} title="Cadastro de Questão"
        right={
          <div className="flex items-center gap-2">
            <Badge color={status === 'published' ? 'success' : status === 'review' ? 'gold' : status === 'draft' ? 'muted' : 'error'}>
              {status === 'draft' ? 'Rascunho' : status === 'review' ? 'Em Revisão' : status === 'published' ? 'Publicada' : 'Arquivada'}
            </Badge>
          </div>
        }
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 max-w-3xl mx-auto w-full" style={{ paddingBottom: 100 }}>
        <div className="flex flex-col gap-6">
          {/* Classification */}
          <Card padding="p-5" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="font-display font-semibold mb-4" style={{ color: C.text }}>Classificação</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Select label="Matéria *" value={subject} onChange={setSubject} options={subjectOptions} placeholder="Selecione..." />
              <Input label="Tema *" type="text" value={theme} onChange={setTheme} placeholder="Ex: Era Vargas" />
              <Input label="Subtema" type="text" value={subtheme} onChange={setSubtheme} placeholder="Ex: Industrialização" />
              <Select label="Dificuldade *" value={difficulty} onChange={setDifficulty}
                options={[{ value: 'easy', label: '🟢 Fácil' }, { value: 'medium', label: '🟡 Médio' }, { value: 'hard', label: '🔴 Difícil' }]}
                placeholder="Selecione..." />
              <Input label="Competência ENEM" type="text" value="" onChange={() => {}} placeholder="Ex: C4 – Conhecimentos" />
              <Input label="Habilidade ENEM" type="text" value="" onChange={() => {}} placeholder="Ex: H15" />
              <Input label="Ano/Origem" type="text" value={year} onChange={setYear} placeholder="Ex: ENEM 2023" />
            </div>
          </Card>

          {/* Content */}
          <Card padding="p-5" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="font-display font-semibold mb-4" style={{ color: C.text }}>Conteúdo da Questão</div>
            <div className="flex flex-col gap-4">
              <Textarea label="Texto de Apoio (opcional)" value={supportText} onChange={setSupportText}
                placeholder="Cole o texto de apoio, contexto histórico, trecho literário, etc." rows={5} />
              <Input label="Fonte do texto" type="text" value={source} onChange={setSource} placeholder="Ex: FAUSTO, Boris. História do Brasil, 2012." />
              <Textarea label="Enunciado da Questão *" value={statement} onChange={setStatement}
                placeholder="Digite o enunciado completo da questão." rows={4} />
            </div>
          </Card>

          {/* Alternatives */}
          <Card padding="p-5" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="font-display font-semibold mb-1" style={{ color: C.text }}>Alternativas</div>
            <p className="text-xs mb-4" style={{ color: C.textMuted }}>O ENEM utiliza 5 alternativas (A a E). Selecione a alternativa correta.</p>
            <div className="flex flex-col gap-3">
              {[
                { id: 'A', val: optA, set: setOptA },
                { id: 'B', val: optB, set: setOptB },
                { id: 'C', val: optC, set: setOptC },
                { id: 'D', val: optD, set: setOptD },
                { id: 'E', val: optE, set: setOptE },
              ].map(opt => (
                <div key={opt.id} className="flex items-start gap-3">
                  <button
                    onClick={() => setCorrect(opt.id)}
                    className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0 mt-6 transition-all"
                    style={{
                      background: correct === opt.id ? 'linear-gradient(135deg,#22c55e,#16a34a)' : 'rgba(255,255,255,0.08)',
                      color: correct === opt.id ? '#fff' : C.textSec,
                      border: `2px solid ${correct === opt.id ? '#22c55e' : 'transparent'}`,
                    }}
                    title={`Marcar ${opt.id} como correta`}
                  >
                    {opt.id}
                  </button>
                  <div className="flex-1">
                    <Input label={`Alternativa ${opt.id}`} type="text" value={opt.val} onChange={opt.set} placeholder={`Texto da alternativa ${opt.id}`} />
                  </div>
                </div>
              ))}
            </div>
            {correct && (
              <div className="mt-3 px-3 py-2 rounded-xl text-sm font-semibold" style={{ background: 'rgba(34,197,94,0.12)', color: C.success }}>
                ✓ Alternativa correta: {correct}
              </div>
            )}
          </Card>

          {/* Pedagogical */}
          <Card padding="p-5" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="font-display font-semibold mb-4" style={{ color: C.text }}>Suporte Pedagógico</div>
            <div className="flex flex-col gap-4">
              <Textarea label="💡 Dica Específica *" value={hint} onChange={setHint} rows={3}
                placeholder="Escreva uma dica que ajude o raciocínio sem revelar a resposta. Seja específico ao conteúdo da questão." />
              <Textarea label="📖 Explicação Pedagógica *" value={explanation} onChange={setExplanation} rows={5}
                placeholder="Explique detalhadamente por que a alternativa correta está certa e por que as outras estão erradas. Contextualize o conteúdo." />
            </div>
          </Card>

          {/* Status */}
          <Card padding="p-4" style={{ background: '#0f1527', border: '1px solid rgba(255,255,255,0.07)' }}>
            <div className="font-semibold text-sm mb-3" style={{ color: C.text }}>Status da Questão</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {([
                { val: 'draft' as FormStatus, label: 'Rascunho', color: C.textMuted },
                { val: 'review' as FormStatus, label: 'Em Revisão', color: C.gold },
                { val: 'published' as FormStatus, label: 'Publicada', color: C.success },
                { val: 'archived' as FormStatus, label: 'Arquivada', color: C.error },
              ]).map(s => (
                <button key={s.val} onClick={() => setStatus(s.val)}
                  className="py-2 rounded-xl text-xs font-semibold transition-all"
                  style={{
                    background: status === s.val ? `${s.color}20` : 'rgba(255,255,255,0.04)',
                    border: `1px solid ${status === s.val ? s.color + '50' : C.border}`,
                    color: status === s.val ? s.color : C.textMuted,
                  }}>
                  {s.label}
                </button>
              ))}
            </div>
          </Card>
        </div>
      </div>

      {/* Actions */}
      <div className="sticky bottom-0 px-4 py-4 flex gap-2"
        style={{ background: 'rgba(6,9,20,0.95)', backdropFilter: 'blur(12px)', borderTop: '1px solid rgba(255,255,255,0.07)' }}>
        <Btn variant="ghost" size="sm" onClick={() => setStatus('draft')}>💾 Salvar Rascunho</Btn>
        <Btn variant="secondary" size="sm" onClick={() => {}}>👁️ Pré-visualizar</Btn>
        <Btn variant="primary" size="sm" full onClick={() => setStatus('review')}>Enviar para Revisão</Btn>
      </div>
    </div>
  )
}
