import { useState } from 'react'
import type { Screen, SubjectKey, SubjectTheme } from '../types'
import { Card, Btn, Stars, Badge, BackHeader, C, Page } from '../ui'
import { subjectMeta, themesBySubject } from '../data'

// ─── Journey Screen (subject selection) ──────────────────────────
export function JourneyScreen({ onNav, onSelectSubject }: {
  onNav: (s: Screen) => void
  onSelectSubject: (s: SubjectKey) => void
}) {
  const subjects: SubjectKey[] = ['history', 'geography', 'philosophy', 'sociology', 'language']
  const progress: Record<SubjectKey, { pct: number; phases: number; total: number }> = {
    history: { pct: 48, phases: 6, total: 16 },
    geography: { pct: 30, phases: 3, total: 10 },
    philosophy: { pct: 55, phases: 4, total: 9 },
    sociology: { pct: 22, phases: 2, total: 7 },
    language: { pct: 60, phases: 3, total: 6 },
  }

  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-5 max-w-3xl mx-auto">
        {/* Header */}
        <div>
          <h1 className="font-display text-2xl font-bold" style={{ color: C.text }}>🗺️ Jornada de Estudos</h1>
          <p className="text-sm mt-1" style={{ color: C.textSec }}>Cada matéria é um território. Explore todos!</p>
        </div>

        {/* Subject cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {subjects.map(subj => {
            const m = subjectMeta[subj]
            const p = progress[subj]
            return (
              <div
                key={subj}
                onClick={() => { onSelectSubject(subj); onNav('subject-map') }}
                className="rounded-2xl overflow-hidden cursor-pointer transition-all hover:scale-[1.02] hover:brightness-105"
                style={{ background: C.bgCard, border: `1px solid ${C.border}`, boxShadow: `0 0 0 0 ${m.color}` }}
              >
                {/* Gradient top stripe */}
                <div className="h-2" style={{ background: m.gradient }} />
                <div className="p-5">
                  <div className="flex items-start justify-between mb-4">
                    <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0" style={{ background: m.bgGlow }}>
                      {m.icon}
                    </div>
                    <Badge color={p.pct >= 70 ? 'success' : p.pct >= 40 ? 'gold' : 'muted'}>
                      {p.pct}% completo
                    </Badge>
                  </div>
                  <h3 className="font-display text-xl font-semibold mb-0.5" style={{ color: C.text }}>{m.label}</h3>
                  <p className="text-xs mb-3" style={{ color: C.textMuted }}>{m.description}</p>

                  {/* Progress */}
                  <div className="mb-2">
                    <div className="h-2 w-full rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.07)' }}>
                      <div className="h-full rounded-full transition-all" style={{ width: `${p.pct}%`, background: m.gradient }} />
                    </div>
                    <div className="flex justify-between text-xs mt-1" style={{ color: C.textMuted }}>
                      <span>{p.phases} fases concluídas</span>
                      <span>{p.total} total</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs font-semibold" style={{ color: m.color }}>
                      {p.pct < 100 ? 'Em progresso' : '✓ Concluído'}
                    </span>
                    <span className="text-xs" style={{ color: C.textMuted }}>→ Explorar</span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </Page>
  )
}

// ─── Phase Node ───────────────────────────────────────────────────
function PhaseNode({ phase, onStart }: { phase: SubjectTheme['phases'][0]; onStart: () => void }) {
  const isLocked = phase.locked
  const isCompleted = phase.completed
  const isBoss = phase.isBoss

  if (isLocked) {
    return (
      <div className="flex items-center gap-3 opacity-45">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl flex-shrink-0"
          style={{ background: 'rgba(255,255,255,0.05)', border: `2px solid rgba(255,255,255,0.08)` }}>
          🔒
        </div>
        <div>
          <div className="text-sm font-semibold" style={{ color: C.textSec }}>{phase.name}</div>
          {isBoss && <Badge size="xs" color="muted">Desafio Final</Badge>}
          <div className="text-xs mt-0.5" style={{ color: C.textMuted }}>Desbloqueie completando as fases anteriores</div>
        </div>
      </div>
    )
  }

  return (
    <div
      onClick={onStart}
      className={`flex items-center gap-3 rounded-2xl p-4 cursor-pointer transition-all hover:scale-[1.01] hover:brightness-105 ${isBoss ? 'ring-1' : ''}`}
      style={{
        background: isCompleted ? 'rgba(34,197,94,0.08)' : isBoss ? 'rgba(245,158,11,0.08)' : 'rgba(255,255,255,0.04)',
        border: isCompleted ? '1px solid rgba(34,197,94,0.2)' : isBoss ? '1px solid rgba(245,158,11,0.25)' : `1px solid ${C.border}`,
      }}
    >
      {/* Circle */}
      <div
        className="w-14 h-14 rounded-2xl flex items-center justify-center text-xl font-display font-bold text-white flex-shrink-0"
        style={{
          background: isCompleted ? 'linear-gradient(135deg,#22c55e,#16a34a)' : isBoss ? 'linear-gradient(135deg,#f59e0b,#d97706)' : 'linear-gradient(135deg,#6366f1,#4f46e5)',
          boxShadow: isCompleted ? '0 4px 16px rgba(34,197,94,0.3)' : isBoss ? '0 4px 16px rgba(245,158,11,0.3)' : '0 4px 16px rgba(99,102,241,0.25)',
        }}
      >
        {isCompleted ? '✓' : isBoss ? '⚔️' : phase.number}
      </div>
      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className="font-semibold text-sm" style={{ color: C.text }}>{phase.name}</span>
          {isBoss && <Badge size="xs" color="gold">Desafio Final</Badge>}
        </div>
        <Stars count={phase.stars} />
        <div className="text-xs mt-0.5" style={{ color: C.textMuted }}>{phase.questionsCount} questões</div>
      </div>
      <span className="text-sm" style={{ color: C.textMuted }}>→</span>
    </div>
  )
}

// ─── Subject Map ──────────────────────────────────────────────────
export function SubjectMapScreen({
  subject,
  onNav,
  onStartPhase,
}: {
  subject: SubjectKey
  onNav: (s: Screen) => void
  onStartPhase: () => void
}) {
  const m = subjectMeta[subject]
  const themes = themesBySubject[subject]
  const [expandedTheme, setExpandedTheme] = useState<string | null>(themes[0]?.id ?? null)

  const totalStars = themes.flatMap(t => t.phases).reduce((s, p) => s + p.stars, 0)
  const maxStars = themes.flatMap(t => t.phases).length * 3
  const completedPhases = themes.flatMap(t => t.phases).filter(p => p.completed).length
  const totalPhases = themes.flatMap(t => t.phases).length

  return (
    <div className="flex flex-col min-h-screen" style={{ background: C.bgDeep }}>
      <BackHeader
        onBack={() => onNav('journey')}
        title={`${m.icon} ${m.label}`}
        right={
          <div className="flex items-center gap-2 text-xs" style={{ color: C.textMuted }}>
            <span>⭐ {totalStars}/{maxStars}</span>
            <span>·</span>
            <span>{completedPhases}/{totalPhases} fases</span>
          </div>
        }
      />

      {/* Subject hero */}
      <div className="px-4 py-4 flex-shrink-0" style={{ background: m.bgGlow, borderBottom: `1px solid ${C.border}` }}>
        <p className="text-sm" style={{ color: C.textSec }}>{m.description}</p>
        <div className="mt-2">
          <div className="h-2 w-full rounded-full overflow-hidden" style={{ background: 'rgba(255,255,255,0.1)' }}>
            <div className="h-full rounded-full" style={{ width: `${(completedPhases / totalPhases) * 100}%`, background: m.gradient }} />
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-3 pb-24">
        {themes.map((theme, idx) => {
          const isOpen = expandedTheme === theme.id
          const done = theme.phases.filter(p => p.completed).length
          const themeStars = theme.phases.reduce((s, p) => s + p.stars, 0)

          return (
            <div key={theme.id} className="flex gap-3">
              {/* Connecting line */}
              <div className="flex flex-col items-center pt-1 flex-shrink-0" style={{ width: 40 }}>
                <div
                  className="w-10 h-10 rounded-xl flex items-center justify-center font-display font-bold text-white text-sm flex-shrink-0"
                  style={{ background: done === theme.phases.length ? m.gradient : 'rgba(255,255,255,0.08)' }}
                >
                  {idx + 1}
                </div>
                {idx < themes.length - 1 && (
                  <div className="flex-1 w-0.5 mt-1" style={{ background: done > 0 ? m.color + '44' : 'rgba(255,255,255,0.07)', minHeight: 24 }} />
                )}
              </div>

              {/* Theme card */}
              <div className="flex-1 min-w-0">
                <div
                  className="rounded-2xl overflow-hidden cursor-pointer"
                  style={{ background: C.bgCard, border: `1px solid ${C.border}` }}
                >
                  {/* Theme header */}
                  <button
                    onClick={() => setExpandedTheme(isOpen ? null : theme.id)}
                    className="w-full flex items-center justify-between p-4 text-left"
                  >
                    <div>
                      <div className="font-display font-semibold" style={{ color: C.text }}>{theme.name}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <Stars count={themeStars} max={theme.phases.length * 3} size={12} />
                        <span className="text-xs" style={{ color: C.textMuted }}>{done}/{theme.phases.length} fases</span>
                      </div>
                    </div>
                    <span className="text-sm transition-transform" style={{ color: C.textMuted, transform: isOpen ? 'rotate(90deg)' : 'none' }}>›</span>
                  </button>

                  {/* Phase list */}
                  {isOpen && (
                    <div className="border-t flex flex-col gap-2 p-3" style={{ borderColor: C.border }}>
                      {theme.phases.map(phase => (
                        <PhaseNode key={phase.id} phase={phase} onStart={onStartPhase} />
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
