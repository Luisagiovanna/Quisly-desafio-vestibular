import type { Screen } from '../types'
import { Card, Btn, ProgressBar, Page, C, SectionTitle } from '../ui'
import { subjectMeta, performanceBySubject, weakTopics } from '../data'

const weekData = [
  { day: 'Seg', value: 45 }, { day: 'Ter', value: 82 }, { day: 'Qua', value: 30 },
  { day: 'Qui', value: 95 }, { day: 'Sex', value: 60 }, { day: 'Sáb', value: 110 }, { day: 'Dom', value: 75 },
]
const maxWeek = Math.max(...weekData.map(d => d.value))

export function PerformanceScreen({ onNav }: { onNav: (s: Screen) => void }) {
  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-6 max-w-3xl mx-auto">
        <div>
          <h1 className="font-display text-2xl font-bold" style={{ color: C.text }}>📊 Meu Desempenho</h1>
          <p className="text-sm mt-1" style={{ color: C.textSec }}>Acompanhe sua evolução e identifique onde melhorar.</p>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { icon: '📝', val: '347', label: 'Questões respondidas', color: C.primaryLight },
            { icon: '✅', val: '74%', label: 'Taxa de acerto', color: C.success },
            { icon: '⭐', val: '1.850', label: 'XP total', color: C.gold },
            { icon: '⏱️', val: '18h', label: 'Tempo estudado', color: C.blue },
          ].map(s => (
            <Card key={s.label} padding="p-4">
              <div className="text-xl mb-1">{s.icon}</div>
              <div className="font-display text-2xl font-bold" style={{ color: s.color }}>{s.val}</div>
              <div className="text-xs" style={{ color: C.textMuted }}>{s.label}</div>
            </Card>
          ))}
        </div>

        {/* Weekly activity chart */}
        <Card elevated>
          <div className="font-display font-semibold mb-4" style={{ color: C.text }}>Atividade Semanal (XP)</div>
          <div className="flex items-end gap-2 h-24">
            {weekData.map((d, i) => {
              const h = (d.value / maxWeek) * 100
              const isToday = i === 5
              return (
                <div key={d.day} className="flex-1 flex flex-col items-center gap-1">
                  <div className="w-full rounded-t-lg relative flex items-end justify-center" style={{ height: 80 }}>
                    <div
                      className="w-full rounded-lg transition-all"
                      style={{
                        height: `${h}%`,
                        background: isToday ? 'linear-gradient(180deg,#6366f1,#4f46e5)' : 'rgba(99,102,241,0.25)',
                        minHeight: 4,
                        boxShadow: isToday ? '0 0 12px rgba(99,102,241,0.4)' : 'none',
                      }}
                    />
                  </div>
                  <span className="text-[10px] font-semibold" style={{ color: isToday ? C.primaryLight : C.textMuted }}>{d.day}</span>
                </div>
              )
            })}
          </div>
        </Card>

        {/* By subject */}
        <div>
          <SectionTitle>Por Matéria</SectionTitle>
          <div className="flex flex-col gap-3">
            {(Object.entries(performanceBySubject) as [keyof typeof performanceBySubject, typeof performanceBySubject[keyof typeof performanceBySubject]][]).map(([key, data]) => {
              const m = subjectMeta[key]
              return (
                <Card key={key} padding="p-4" onClick={() => onNav('journey')}>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0" style={{ background: m.bgGlow }}>{m.icon}</div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-semibold text-sm" style={{ color: C.text }}>{m.label}</span>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-base" style={{ color: m.color }}>{data.pct}%</span>
                          <span className="text-xs font-semibold" style={{ color: data.trend >= 0 ? C.success : C.error }}>
                            {data.trend >= 0 ? '▲' : '▼'} {Math.abs(data.trend)}%
                          </span>
                        </div>
                      </div>
                      <ProgressBar value={data.pct} max={100} color={m.gradient} height={6} animated />
                    </div>
                  </div>
                  <div className="flex gap-2 ml-13">
                    <span className="text-xs px-2 py-0.5 rounded-lg font-semibold" style={{ background: data.pct >= 75 ? 'rgba(34,197,94,0.12)' : 'rgba(245,158,11,0.12)', color: data.pct >= 75 ? C.success : C.gold }}>
                      {data.pct >= 75 ? '✓ Bom domínio' : '⚠ Requer atenção'}
                    </span>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Strength / Weakness */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* You dominate */}
          <Card padding="p-4">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xl">💪</span>
              <div className="font-display font-semibold" style={{ color: C.success }}>Você Domina</div>
            </div>
            {[
              { subject: 'language' as const, topic: 'Reading Comprehension', pct: 91 },
              { subject: 'philosophy' as const, topic: 'Filosofia Clássica', pct: 84 },
            ].map(item => {
              const m = subjectMeta[item.subject]
              return (
                <div key={item.topic} className="flex items-center justify-between py-2 border-b last:border-0"
                  style={{ borderColor: C.border }}>
                  <div className="flex items-center gap-2">
                    <span className="text-base">{m.icon}</span>
                    <span className="text-sm" style={{ color: C.textSec }}>{item.topic}</span>
                  </div>
                  <span className="font-bold text-sm" style={{ color: C.success }}>{item.pct}%</span>
                </div>
              )
            })}
          </Card>

          {/* Needs review */}
          <Card padding="p-4">
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xl">🎯</span>
              <div className="font-display font-semibold" style={{ color: C.gold }}>Precisa Revisar</div>
            </div>
            {weakTopics.map(item => {
              const m = subjectMeta[item.subject]
              return (
                <div key={item.topic} className="flex items-center justify-between py-2 border-b last:border-0"
                  style={{ borderColor: C.border }}>
                  <div className="flex items-center gap-2">
                    <span className="text-base">{m.icon}</span>
                    <div>
                      <div className="text-sm" style={{ color: C.textSec }}>{item.topic}</div>
                      <div className="text-xs" style={{ color: C.error }}>{item.pct}% acertos</div>
                    </div>
                  </div>
                  <Btn variant="outline" size="xs" onClick={() => onNav('question')}>TREINAR</Btn>
                </div>
              )
            })}
          </Card>
        </div>

        {/* More stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {[
            { icon: '🔥', val: '7', label: 'Dias de sequência', color: '#fb923c' },
            { icon: '📋', val: '3', label: 'Simulados realizados', color: C.blue },
            { icon: '✍️', val: '2', label: 'Redações enviadas', color: '#f472b6' },
          ].map(s => (
            <Card key={s.label} padding="p-4 text-center">
              <div className="text-2xl mb-1">{s.icon}</div>
              <div className="font-display text-3xl font-bold" style={{ color: s.color }}>{s.val}</div>
              <div className="text-xs" style={{ color: C.textMuted }}>{s.label}</div>
            </Card>
          ))}
        </div>
      </div>
    </Page>
  )
}
