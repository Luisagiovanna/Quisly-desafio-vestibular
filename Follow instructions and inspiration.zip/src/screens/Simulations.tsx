import { useState, useEffect } from 'react'
import type { Screen } from '../types'
import { Card, Btn, Badge, ProgressBar, BackHeader, Page, C, SectionTitle } from '../ui'
import { sampleQuestions, subjectMeta } from '../data'

// ─── Simulations Hub ─────────────────────────────────────────────
export function SimulationsScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const simTypes = [
    {
      id: 'quick', icon: '⚡', title: 'Simulado Rápido', desc: '10 questões', detail: '≈ 15 minutos · Todas as matérias', color: '#6366f1',
      gradient: 'linear-gradient(135deg,#6366f1,#4f46e5)', glow: 'rgba(99,102,241,0.2)',
    },
    {
      id: 'history', icon: '🏛️', title: 'Ciências Humanas', desc: '30 questões', detail: '≈ 45 minutos · História + Geo + Fil + Soc', color: '#f87171',
      gradient: 'linear-gradient(135deg,#ef4444,#dc2626)', glow: 'rgba(239,68,68,0.15)',
    },
    {
      id: 'full', icon: '📋', title: 'Simulado Completo', desc: '45 questões', detail: '≈ 90 minutos · Todas as matérias + Redação', color: '#f59e0b',
      gradient: 'linear-gradient(135deg,#f59e0b,#d97706)', glow: 'rgba(245,158,11,0.15)',
    },
  ]

  const pastSimulations = [
    { date: '18/09/2026', type: 'Simulado Rápido', score: '7/10', pct: 70, time: '12:34' },
    { date: '14/09/2026', type: 'Ciências Humanas', score: '21/30', pct: 70, time: '41:20' },
    { date: '09/09/2026', type: 'Simulado Rápido', score: '6/10', pct: 60, time: '13:55' },
  ]

  return (
    <Page>
      <div className="px-4 py-5 flex flex-col gap-5 max-w-3xl mx-auto">
        <div>
          <h1 className="font-display text-2xl font-bold" style={{ color: C.text }}>📝 Simulados</h1>
          <p className="text-sm mt-1" style={{ color: C.textSec }}>Teste seus conhecimentos sem dicas e com cronômetro.</p>
        </div>

        {/* Mode cards */}
        <div className="flex flex-col gap-3">
          {simTypes.map(sim => (
            <Card key={sim.id} glow={sim.glow} padding="p-0">
              <div className="p-5 flex items-center gap-4">
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center text-3xl flex-shrink-0"
                  style={{ background: sim.gradient }}>
                  {sim.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-display text-lg font-semibold" style={{ color: C.text }}>{sim.title}</div>
                  <div className="text-sm font-semibold" style={{ color: sim.color }}>{sim.desc}</div>
                  <div className="text-xs mt-0.5" style={{ color: C.textMuted }}>{sim.detail}</div>
                </div>
                <Btn variant="primary" size="sm" onClick={() => onNav('sim-run')}>Iniciar</Btn>
              </div>
            </Card>
          ))}
        </div>

        {/* Rules */}
        <Card padding="p-4">
          <div className="font-semibold text-sm mb-3" style={{ color: C.textSec }}>📋 Regras do Simulado</div>
          <div className="flex flex-col gap-2">
            {[
              '⏱️ Cronômetro ativo do início ao fim',
              '🚫 Sem dicas durante a prova',
              '❌ Sem segunda tentativa nas questões',
              '↔️ Pode avançar e voltar entre questões',
              '📊 Resultado e análise apenas no final',
            ].map(rule => (
              <div key={rule} className="text-xs flex items-start gap-2" style={{ color: C.textSec }}>
                <span>{rule}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* History */}
        <div>
          <SectionTitle>Histórico de Simulados</SectionTitle>
          {pastSimulations.length === 0 ? (
            <div className="text-center py-8 text-sm" style={{ color: C.textMuted }}>Nenhum simulado realizado ainda.</div>
          ) : (
            <div className="flex flex-col gap-2">
              {pastSimulations.map((s, i) => (
                <Card key={i} padding="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-sm" style={{ color: C.text }}>{s.type}</div>
                      <div className="text-xs mt-0.5" style={{ color: C.textMuted }}>{s.date} · {s.time}</div>
                    </div>
                    <div className="text-right">
                      <div className="font-display text-lg font-bold" style={{ color: s.pct >= 70 ? C.success : s.pct >= 50 ? C.gold : C.error }}>
                        {s.score}
                      </div>
                      <div className="text-xs" style={{ color: C.textMuted }}>{s.pct}% acertos</div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </Page>
  )
}

// ─── Simulation Run ───────────────────────────────────────────────
export function SimRunScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const questions = sampleQuestions.concat(sampleQuestions).concat(sampleQuestions).slice(0, 10)
  const [qIdx, setQIdx] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [elapsed, setElapsed] = useState(0)

  useEffect(() => {
    const id = setInterval(() => setElapsed(t => t + 1), 1000)
    return () => clearInterval(id)
  }, [])

  const mins = String(Math.floor(elapsed / 60)).padStart(2, '0')
  const secs = String(elapsed % 60).padStart(2, '0')
  const q = questions[qIdx]
  const answered = answers[qIdx]

  function handleFinish() {
    onNav('sim-result')
  }

  return (
    <div className="flex flex-col min-h-screen" style={{ background: C.bgDeep }}>
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 flex-shrink-0"
        style={{ background: C.bgSurface, borderBottom: `1px solid ${C.border}` }}>
        <button onClick={() => onNav('simulations')} className="text-xs font-semibold" style={{ color: C.error }}>
          ✕ Encerrar
        </button>
        <div className="flex items-center gap-4">
          <span className="font-mono text-base font-bold" style={{ color: C.gold }}>⏱️ {mins}:{secs}</span>
          <span className="text-sm" style={{ color: C.textSec }}>{qIdx + 1}/{questions.length}</span>
        </div>
        <Btn variant="success" size="xs" onClick={handleFinish}>Finalizar</Btn>
      </div>

      {/* Progress */}
      <div className="flex px-4 gap-1 py-2 flex-shrink-0" style={{ background: C.bgSurface }}>
        {questions.map((_, i) => (
          <button
            key={i}
            onClick={() => setQIdx(i)}
            className="h-2 flex-1 rounded-full transition-all"
            style={{
              background: i === qIdx ? C.primary : answers[i] ? 'rgba(99,102,241,0.5)' : 'rgba(255,255,255,0.1)',
            }}
          />
        ))}
      </div>

      {/* Question */}
      <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-4" style={{ paddingBottom: 100 }}>
        {q.supportText && (
          <Card padding="p-4">
            <p className="text-xs font-semibold uppercase mb-1.5" style={{ color: C.textMuted }}>Texto de Apoio</p>
            <p className="text-sm italic leading-relaxed" style={{ color: C.textSec }}>{q.supportText}</p>
            {q.source && <p className="text-xs mt-2" style={{ color: C.textMuted }}>{q.source}</p>}
          </Card>
        )}

        <p className="font-semibold leading-relaxed" style={{ color: C.text }}>{q.statement}</p>

        <div className="flex flex-col gap-2.5">
          {q.options.map(opt => (
            <button
              key={opt.id}
              onClick={() => setAnswers(a => ({ ...a, [qIdx]: opt.id }))}
              className="flex items-start gap-3 w-full text-left rounded-xl px-4 py-3.5 transition-all hover:brightness-110"
              style={{
                background: answered === opt.id ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${answered === opt.id ? 'rgba(99,102,241,0.5)' : C.border}`,
              }}
            >
              <span className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-sm flex-shrink-0"
                style={{ background: answered === opt.id ? C.primary : 'rgba(255,255,255,0.1)', color: '#fff' }}>
                {opt.id}
              </span>
              <span className="text-sm leading-relaxed" style={{ color: answered === opt.id ? C.text : C.textSec }}>{opt.text}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Footer nav */}
      <div className="fixed bottom-0 left-0 right-0 flex gap-3 px-4 py-3"
        style={{ background: C.bgSurface, borderTop: `1px solid ${C.border}`, paddingBottom: 'max(12px, env(safe-area-inset-bottom))' }}>
        <Btn variant="ghost" size="md" full onClick={() => setQIdx(i => Math.max(0, i - 1))} disabled={qIdx === 0}>← Anterior</Btn>
        {qIdx < questions.length - 1
          ? <Btn variant="primary" size="md" full onClick={() => setQIdx(i => Math.min(questions.length - 1, i + 1))}>Próxima →</Btn>
          : <Btn variant="success" size="md" full onClick={handleFinish}>✓ Finalizar Prova</Btn>
        }
      </div>
    </div>
  )
}

// ─── Simulation Result ────────────────────────────────────────────
export function SimResultScreen({ onNav }: { onNav: (s: Screen) => void }) {
  const results = { total: 10, correct: 7, wrong: 2, skipped: 1, time: '13:47' }
  const pct = Math.round((results.correct / results.total) * 100)

  const bySubject = [
    { subject: 'history' as const, label: 'História', correct: 3, total: 4 },
    { subject: 'geography' as const, label: 'Geografia', correct: 2, total: 3 },
    { subject: 'philosophy' as const, label: 'Filosofia', correct: 1, total: 2 },
    { subject: 'sociology' as const, label: 'Sociologia', correct: 1, total: 1 },
  ]

  const weak = [
    { subject: 'philosophy' as const, topic: 'Contratualismo', pct: 50 },
    { subject: 'sociology' as const, topic: 'Movimentos Sociais', pct: 60 },
  ]

  return (
    <div className="min-h-screen flex flex-col" style={{ background: C.bgDeep }}>
      <BackHeader onBack={() => onNav('simulations')} title="Resultado do Simulado" />

      <div className="flex-1 overflow-y-auto px-4 py-5 flex flex-col gap-5 max-w-2xl mx-auto w-full" style={{ paddingBottom: 80 }}>
        {/* Score */}
        <Card elevated padding="p-6">
          <div className="text-center mb-4">
            <div className="font-display text-6xl font-bold mb-1" style={{ color: pct >= 70 ? C.success : pct >= 50 ? C.gold : C.error }}>
              {results.correct}/{results.total}
            </div>
            <div className="text-sm" style={{ color: C.textSec }}>{pct}% de acertos</div>
          </div>
          <div className="h-3 rounded-full overflow-hidden mb-3" style={{ background: 'rgba(255,255,255,0.08)' }}>
            <div className="h-full rounded-full" style={{ width: `${pct}%`, background: pct >= 70 ? `linear-gradient(90deg,${C.success},#4ade80)` : `linear-gradient(90deg,${C.gold},#fbbf24)` }} />
          </div>
          <div className="grid grid-cols-3 gap-3 mt-2">
            {[
              { icon: '✅', label: 'Corretas', val: results.correct, color: C.success },
              { icon: '❌', label: 'Erradas', val: results.wrong, color: C.error },
              { icon: '⏭️', label: 'Puladas', val: results.skipped, color: C.textMuted },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className="font-display text-2xl font-bold" style={{ color: s.color }}>{s.val}</div>
                <div className="text-xs" style={{ color: C.textMuted }}>{s.label}</div>
              </div>
            ))}
          </div>
          <div className="text-center mt-3 text-sm" style={{ color: C.textMuted }}>⏱️ Tempo: {results.time}</div>
        </Card>

        {/* By subject */}
        <div>
          <SectionTitle>Desempenho por Matéria</SectionTitle>
          <div className="flex flex-col gap-2.5">
            {bySubject.map(s => {
              const m = subjectMeta[s.subject]
              const p = Math.round((s.correct / s.total) * 100)
              return (
                <Card key={s.subject} padding="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xl">{m.icon}</span>
                    <span className="font-semibold text-sm flex-1" style={{ color: C.text }}>{s.label}</span>
                    <span className="font-bold text-sm" style={{ color: m.color }}>{s.correct}/{s.total} ({p}%)</span>
                  </div>
                  <ProgressBar value={s.correct} max={s.total} color={m.gradient} height={6} animated />
                </Card>
              )
            })}
          </div>
        </div>

        {/* Weak topics */}
        <div>
          <SectionTitle>Pontos para Revisar</SectionTitle>
          <div className="flex flex-col gap-2">
            {weak.map(w => {
              const m = subjectMeta[w.subject]
              return (
                <Card key={w.topic} padding="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{m.icon}</span>
                      <div>
                        <div className="font-semibold text-sm" style={{ color: C.text }}>{w.topic}</div>
                        <div className="text-xs" style={{ color: C.textMuted }}>{m.label} · {w.pct}% acertos</div>
                      </div>
                    </div>
                    <Btn variant="outline" size="xs" onClick={() => onNav('question')}>TREINAR</Btn>
                  </div>
                </Card>
              )
            })}
          </div>
        </div>

        <div className="flex gap-3">
          <Btn variant="primary" size="md" full onClick={() => onNav('question')}>📚 TREINAR ESTES CONTEÚDOS</Btn>
          <Btn variant="ghost" size="md" full onClick={() => onNav('simulations')}>Novo Simulado</Btn>
        </div>
      </div>
    </div>
  )
}
